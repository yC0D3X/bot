const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ApplicationCommandOptionType, PermissionFlagsBits } = require("discord.js");

module.exports = {
    name: 'setticket',
    description: 'Define a mensagem de suporte.',
    default_member_permissions: [PermissionFlagsBits.Administrator],
    options: [
        {
            name: "canal",
            description: "Canal para enviar a mensagem do ticket.",
            type: ApplicationCommandOptionType.Channel,
            required: true
        }
    ],
    exec: async ({ client, interaction }) => {
        if(![client.config.ownerId].includes(interaction.user.id)) return interaction.reply({ content: "Somente o Adm pode usar este comando", ephemeral: true })
        const { Ticket } = client.config
        const { menus } = Ticket
        const options = menus.map(menu => menu.opções).flat()
        
        const channel = interaction.options.getChannel("canal")

        const embed = new EmbedBuilder()
            .setDescription(`${interaction.user}, Enviar os menus do ticket **Selecione qual dos menus deseja enviar.**.`)
            .setColor(client.config.mainColor)
            .setTimestamp();

        const menu = new ActionRowBuilder()
		.addComponents(
			new StringSelectMenuBuilder()
				.setCustomId('select')
				.setPlaceholder("Selecione qual menu deseja enviar")
				.addOptions(
				  client.config.Ticket.menus.map((option, i) => {
				    return {
				      label: option.identificador,
				      value: "choice:" + i,
				    }
				  })
				)
		);
        
        interaction.reply({ embeds: [embed], components: [menu], fetchreply: true, ephemeral: true }).then(msg=>{
            const collector = msg.createMessageComponentCollector({ time: 30000, max: 1 });

            collector.on('collect', i => {
                const index = i.values[0].split(":")[1]
                const menu = client.config.Ticket.menus[index]

                const meniu = new ActionRowBuilder()
                .addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId('menuSelectTicketOpen')
                        .setPlaceholder(menu.mensagemInicial || "Selecione uma categoria de ticket")
                        .addOptions(
                        menu.opções.map((option, i) => {
                            return {
                            label: option.nome,
                            value: "menuChoice:" + options.findIndex(op=> op.name == option.name && op.description == option.description),
                            description: option.description,
                            emoji: option.emoji
                            }
                        })
                        )
                );

                channel.send({ embeds: [menu.embed], components: [meniu] }).catch(e=>{
                    console.log(`Não foi possivel enviar a mensagem de menus do ticket em ${channel.name} pois: ${e}`)
                })

                i.update({ content: "Mensagem enviada com sucesso!", embeds: [], components: [] })
            });

        })
        
    }
}