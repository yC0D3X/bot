const { EmbedBuilder } = require('discord.js');
const { Vulkava } = require('vulkava');
const lastTimestampsInitSound = new Map()
module.exports = async(client) =>{
  client.lastTimestampsInitSound = lastTimestampsInitSound
  client.vulkava = new Vulkava({
    nodes: [
      {
        hostname: "aubrinha.discloud.app",
        port: 443,
        secure: true,
        password: "otrembao",
      },
    ],
    sendWS: (guildId, payload) => {
      client.guilds.cache.get(guildId)?.shard.send(payload);
    }
  })
  
  client.vulkava.on('trackStart', (player, track) => {
    const channel = client.channels.cache.get(player.textChannelId);
    const voiceChannel = client.channels.cache.get(player.voiceChannelId);
    
    if(voiceChannel.members.get(client.user.id) && voiceChannel.members.size <= 1){
      channel.send({ embeds: [
        new EmbedBuilder()
        .setAuthor({ name: `Lista de reprodução encerrada por falta de membros na call.`, iconURL: client.user.avatarURL() })
        .setColor(client.config.mainColor)
      ]})

      return player.destroy()
    }

    lastTimestampsInitSound.set(player.guildId, Date.now())
    channel.send({ embeds: [
      new EmbedBuilder()
      .setTitle(`${track.title}`)
      .setURL(track.metadata?.uri || track.uri)
      .setAuthor({ name: `Tocando agora:` })
      .setThumbnail(track.thumbnail)
      .setColor(client.config.mainColor)
    ]})
  });
  
  client.vulkava.on('queueEnd', (player) => {
    const channel = client.channels.cache.get(player.textChannelId);
    lastTimestampsInitSound.delete(player.guildId)
    channel.send({ embeds: [
      new EmbedBuilder()
      .setAuthor({ name: `Lista de reprodução encerrada.`, iconURL: client.user.avatarURL() })
      .setColor(client.config.mainColor)
    ]});
  
    player.destroy();
  });
  
  client.vulkava.on('error', (node, err) => {
    if(node.identifier.includes("1006") || err.message.includes("1006")) return;
    console.error(`[VULKAVA] erro ${node.identifier}`, err.message);
  });
  
  client.on('ready', () => {
    client.vulkava.start(client.user.id);
    console.log("[LAVALINK] Sistema de música online.")
  });
  
  client.on('raw', (packet) => client.vulkava.handleVoiceUpdate(packet));
  
}