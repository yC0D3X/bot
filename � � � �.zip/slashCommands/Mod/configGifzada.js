const Discord = require("discord.js");
const { guildActivadeSystem, initCountGifzada } = require("../../eventListeners/guildSystems/gifzada");

module.exports = {
    name: 'gifzada',
    description: '.',
    options: [
        {
            name: "configs",
            description: "Configurar sistema de icons, gifs e banners",
            type: Discord.ApplicationCommandOptionType.Subcommand,
        }
    ],
    default_member_permissions: 0,
    exec: async ({client, interaction}) => {
        const guildDb = async ()=> await client.dbGuild.findOne({ _id: interaction.guild.id }) || await client.dbGuild.create({ _id: interaction.guild.id })

        const cancelButton = new Discord.ActionRowBuilder()
        .addComponents(
            new Discord.ButtonBuilder()
            .setCustomId(`cancel`)
            .setEmoji("<:X_:1151936937540726905>")
            .setLabel('Cancelar')
            .setStyle(Discord.ButtonStyle.Secondary),
        );

        const generateMessage = async() =>{
            const databaseOfGuild = await guildDb()
            function getChannel(param){
                return interaction.guild.channels.cache.get(databaseOfGuild.gifzadaSystem.partials[param].channel)
            }
            const embedConfig = new Discord.EmbedBuilder()
            .setAuthor({ name: `Configurar gifzada bot em ${interaction.guild.name}`, iconURL: interaction.guild.iconURL()})
            .addFields(
                {
                    name: `> **Status do sistema:** `,
                    value: client.selfBot.fetchInProgress ? "`🔴 Offline`" : "`🟢 Online`",
                    inline: false
                },
                {
                    name: `> **Sistema ativado no servidor:** `,
                    value: databaseOfGuild.gifzadaSystem.active ? "`✅ Ativo`" : "`❌ Desativado`",
                    inline: false
                },
                {
                    name: `> **Tempo de cooldown:** `,
                    value: `\`${transformSeconds(databaseOfGuild.gifzadaSystem.cooldown)}\``,
                    inline: false
                },
                {
                    name: `> **Avatares animados:** `,
                    value: databaseOfGuild.gifzadaSystem.partials.animate.active && getChannel("animate") ? `${getChannel("animate")}` : "`❌ Desativado`",
                    inline: true
                },
                {
                    name: `> **Avatares estáticos:** `,
                    value: databaseOfGuild.gifzadaSystem.partials.static.active && getChannel("static") ? `${getChannel("static")}` : "`❌ Desativado`",
                    inline: true
                },
                {
                    name: `> **Banners:** `,
                    value: databaseOfGuild.gifzadaSystem.partials.banner.active && getChannel("banner") ? `${getChannel("banner")}` : "`❌ Desativado`",
                    inline: true
                }
            )
            .setColor(client.config.mainColor);
            
            const buttonsConfigEnter = new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`e`)
                    .setLabel('Avatares animados:')
                    .setDisabled(true)
                    .setStyle(Discord.ButtonStyle.Success),
                    new Discord.ButtonBuilder()
                    .setCustomId("active.desactive/animate")
                    .setLabel(databaseOfGuild.gifzadaSystem.partials.animate.active && getChannel("animate") ? "Desativar" : "Ativar")
                    .setEmoji(databaseOfGuild.gifzadaSystem.partials.animate.active && getChannel("animate") ? "<:OnBlue:1152616795350499458>" : "<:Off:1149308391324401674>")
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`setChannel/animate`)
                    .setEmoji("<:Hash:1149342519855947886>")
                    .setLabel('Setar Canal')
                    .setDisabled(!databaseOfGuild.gifzadaSystem.partials.animate.active)
                    .setStyle(Discord.ButtonStyle.Secondary),
            );
            const buttonsConfigOut = new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`a`)
                    .setLabel('Avatares estáticos:')
                    .setDisabled(true)
                    .setStyle(Discord.ButtonStyle.Success),
                    new Discord.ButtonBuilder()
                    .setCustomId("active.desactive/static")
                    .setLabel(databaseOfGuild.gifzadaSystem.partials.static.active && getChannel("static") ? "Desativar" : "Ativar")
                    .setEmoji(databaseOfGuild.gifzadaSystem.partials.static.active && getChannel("static") ? "<:OnBlue:1152616795350499458>" : "<:Off:1149308391324401674>")
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`setChannel/static`)
                    .setEmoji("<:Hash:1149342519855947886>")
                    .setLabel('Setar Canal')
                    .setDisabled(!databaseOfGuild.gifzadaSystem.partials.static.active)
                    .setStyle(Discord.ButtonStyle.Secondary),
            );
            const buttonsConfigMessages = new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`aa`)
                    .setLabel('Banners:')
                    .setDisabled(true)
                    .setStyle(Discord.ButtonStyle.Success),
                    new Discord.ButtonBuilder()
                    .setCustomId("active.desactive/banner")
                    .setLabel(databaseOfGuild.gifzadaSystem.partials.banner.active && getChannel("banner") ? "Desativar" : "Ativar")
                    .setEmoji(databaseOfGuild.gifzadaSystem.partials.banner.active && getChannel("banner") ? "<:OnBlue:1152616795350499458>" : "<:Off:1149308391324401674>")
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`setChannel/banner`)
                    .setEmoji("<:Hash:1149342519855947886>")
                    .setLabel('Setar Canal')
                    .setDisabled(!databaseOfGuild.gifzadaSystem.partials.banner.active)
                    .setStyle(Discord.ButtonStyle.Secondary),
            );
            const finishConfigs = new Discord.ActionRowBuilder()
            .addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId("active.desactive/system")
                    .setLabel(databaseOfGuild.gifzadaSystem.active ? "Desativar sistema" : "Ativar sistema")
                    .setEmoji(databaseOfGuild.gifzadaSystem.active ? "<:OnBlue:1152616795350499458>" : "<:Off:1149308391324401674>")
                    .setDisabled(![databaseOfGuild.gifzadaSystem.partials.banner.active, databaseOfGuild.gifzadaSystem.partials.static.active, databaseOfGuild.gifzadaSystem.partials.animate.active].includes(true))
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`changeCooldown`)
                    .setEmoji("<:Config:1149343912062898186>")
                    .setLabel('Mudar Cooldoown')
                    .setStyle(Discord.ButtonStyle.Secondary),
            );

            return { embeds: [embedConfig], components: [buttonsConfigEnter, buttonsConfigOut, buttonsConfigMessages, finishConfigs], fetchReply: true, ephemeral: true }
        }
            
        interaction.reply(await generateMessage()).then(msg=>{
            
            const collector = msg.createMessageComponentCollector({ idle: 1000 * 60 * 5 });

            collector.on('collect', async i => {
                if(i.isButton()){

                    function createMenuChannel(){
                        const channelsRow = new Discord.ActionRowBuilder()
                            .addComponents(
                                new Discord.ChannelSelectMenuBuilder()
                                .setCustomId(Button)
                                .setPlaceholder('Canal que será enviado as mensagens')
                                .setChannelTypes([Discord.ChannelType.GuildText])
                            );
                            i.update({ components: [channelsRow, cancelButton]})
                    }

                    const { customId: Button } = i

                    if(Button == "cancel"){
                        i.update(await generateMessage())
                    }
                    if(Button == "changeCooldown"){
                        const databaseOfGuild = await guildDb()
                        const timeNow = Date.now()
                        const modal = new Discord.ModalBuilder()
                            .setCustomId(`timeModal/${timeNow}`)
                            .setTitle('Alterar cooldown do sistema');

                        const time = new Discord.TextInputBuilder()
                        .setCustomId('time')
                        .setLabel("Tempo em segundos:")
                        .setValue(`${databaseOfGuild.gifzadaSystem.cooldown / 1000}`)
                        .setStyle(Discord.TextInputStyle.Short);

                        const timeRow = new Discord.ActionRowBuilder().addComponents(time);
                        modal.addComponents(timeRow);
                        i.showModal(modal)
                        i.awaitModalSubmit({ filter: (interaction) => interaction.customId === `timeModal/${timeNow}`, time: 10_000, max: 1 })
                            .then(async interactionModal => {
                                const time = interactionModal.fields.getTextInputValue('time');
                                if(isNaN(time)) return interactionModal.reply({ content: `> Tempo inválido, digite apenas números em segundos.`, ephemeral: true})
                                if(time < 10) return interactionModal.reply({ content: `> Tempo muito curto, o mínimo de tempo possível são 10 segundos.`, ephemeral: true})
                               
                                await client.dbGuild.updateOne({ _id: interactionModal.guild.id },{
                                    $set: {
                                        "gifzadaSystem.cooldown": time * 1000
                                    } 
                                })

                                interaction.editReply(await generateMessage())
                                interactionModal.reply({ content: `> Cooldown alterado com sucesso.`, ephemeral: true})
                                if(guildActivadeSystem[databaseOfGuild._id] && !guildActivadeSystem[databaseOfGuild._id]?._destroyed){
                                    clearInterval(guildActivadeSystem[databaseOfGuild._id])
                                    initCountGifzada(await guildDb(), client.selfBot, client)
                                }
                            }, err=>{})
                    }
                    
                    if(Button.startsWith("setChannel/")){
                        createMenuChannel()
                    }

                    if(Button.startsWith("active.desactive/")){
                        const [, database] = Button.split("/")
                        if(database == "system"){

                            const databaseOfGuild = await guildDb()

                            if(!databaseOfGuild.gifzadaSystem.active && !databaseOfGuild.gifzadaSystem.admPermToUse){
                                return i.reply({ content: "> **Não sou autorizado a ligar esse sistema neste servidor.**", ephemeral: true })
                            }

                            if(databaseOfGuild.gifzadaSystem.active){
                                clearInterval(guildActivadeSystem[databaseOfGuild._id])
                            } else {
                                initCountGifzada(await guildDb(), client.selfBot, client)
                            }

                             await client.dbGuild.updateOne({ _id: i.guild.id },{
                                 $set: {
                                     "gifzadaSystem.active": !databaseOfGuild.gifzadaSystem.active
                                 } 
                             })
                             return i.update(await generateMessage())
                        }

                        const setDatabase = {}

                        setDatabase[`gifzadaSystem.partials.${database}`] = {
                            active: false
                        }

                        const databaseOfGuild = await guildDb()

                        if(databaseOfGuild.gifzadaSystem.partials[database].active){
                            await client.dbGuild.updateOne({ _id: i.guild.id },{
                                $set: setDatabase
                            })
                            
                            const { gifzadaSystem } = await guildDb()
                            if(gifzadaSystem.active 
                                && [gifzadaSystem.partials.animate.active,
                                gifzadaSystem.partials.banner.active,
                                gifzadaSystem.partials.static.active 
                            ].every(a=>!a)){
                                await client.dbGuild.updateOne({ _id: i.guild.id },{
                                    $set: {
                                        "gifzadaSystem.active": false
                                    }
                                })
                                clearInterval(guildActivadeSystem[databaseOfGuild._id])
                            }
                            i.update(await generateMessage())
                        } else {
                            createMenuChannel()
                        }
                        
                    }
                }
                
                if(i.isChannelSelectMenu()){
                    const [, database] = i.customId.split("/")
                    const channel = i.guild.channels.cache.get(i.values[0])

                    const setDatabase = {}

                        setDatabase[`gifzadaSystem.partials.${database}`] = {
                            active: true,
                            channel: channel.id
                        }
                    
                    await client.dbGuild.updateOne({ _id: i.guild.id },{
                        $set: setDatabase
                    })
                    await i.update(await generateMessage())
                }
            });

        })
    }
}

function transformSeconds(sec){
    const segundosTotal = ~~(sec / 1000)
    const minutos = ~~(segundosTotal / 60)
    const horas = ~~(minutos / 60)
    const segundos = segundosTotal % 60
    return [`${horas% 60}h`,`${minutos% 60}m`, `${segundos}s`].filter(num => !num.startsWith("0")).map(num => num.padStart(3,0)).join(" ")
  }