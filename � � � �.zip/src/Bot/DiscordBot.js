const { Client } = require('discord.js');
const Mongoose = require('mongoose');
const config = require('../util/config.js');
const Loader = require('../util/Loader.js');
const webStart = require("../Web/express.js")
const lavalinkStart = require("./Lavalink.js")
const selfBot = require("./SelfBot.js")

module.exports = class DiscordBot extends Client {
    constructor(options = {}) {
        super(options.discord);

        this.config = config;
        this.configLogs = config;
        this.token = options.token;
        this.mainGuild = null;
        this.prefix = this.config.prefix;
        this.dbGuild = require("../Database/guild.js")
        this.dbUser = require("../Database/user.js")
        this.webServerPassword = ""
        
        this.loader = new Loader(this);
        this.selfBot = new selfBot(process.env.SELFBOT_TOKEN)
        this.connectMongo()
        this.login(this.token);

    }
   
    async connectMongo(){
        Mongoose.set('strictQuery', true);
        Mongoose.connect(process.env.MONGO).then(()=>{
            console.log("[DATABASE] MongoDb Conectada com sucesso.")
        })
    }
    
    async runningWebServer(){
        webStart(this)
    }
    
    async runningLavalink(){
        lavalinkStart(this)
    }

    async login(token) {
        this.loader.loadAll();
        this.runningWebServer()
        this.runningLavalink()
        await super.login(token);
    }

}