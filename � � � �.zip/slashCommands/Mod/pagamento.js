const { PermissionFlagsBits, ApplicationCommandOptionType } = require("discord.js");

module.exports = {
  name: "pix",
  description: "conta para pagamento",
  dm_permission: false,
    exec: async ({client, interaction}) => {
		await interaction.reply({
			content:'> Bom... já verificou os valores em <#1142101648227979356>  certinho ? se já viu, e sabe onde ficam os cofres, basta escolher o plano que mais lhe agrada e fazer a transferência para a conta `311`, assim que a fizer, basta enviar um print mostrando as `logs do banco` junto a senha desejada, e lhe informarei o cofre. <a:876104193138622544:1164986309958451251>',
			ephemeral: false
		})
	},
};