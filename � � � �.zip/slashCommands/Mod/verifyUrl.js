const Discord = require('discord.js');
const axios = require('axios').default;
const cooldowns = new Discord.Collection();

module.exports = {
    name: "verificar-url",
    description: `Verificação por URL`,
    type: Discord.ApplicationCommandType.ChatInput,
    exec: async ({client, interaction}) => {
        interaction.reply({ content: `Painel enviado`, ephemeral: true });

        const iddocanal = "1208390759846248509"; // Adicione o ID do canal que vai enviar a embed
        const cargos = "1208393229427408896"; // Adicione o ID do cargo de verificado
        const idcanallogs = "1086023896735698946"; // Adicione o ID do canal de logs aqui
        const embed = new Discord.EmbedBuilder()
            .setDescription(`Gostou do servidor e quer fazer parte da nossa comunidade? Coloque alguma das nossas urls na sua bio e verifique-se para ganhar cargos exclusivos no servidor!\n\n**Url disponivel:**\ndsc.gg/bianchis`);
        const botao = new Discord.ButtonBuilder()
            .setCustomId("verifurl")
            .setLabel("Verificar")
            .setStyle(2);
        const base = new Discord.ActionRowBuilder().addComponents(botao);

        const MESSAGE = await client.channels.cache.get(iddocanal).send({ embeds: [embed], components: [base] });
        const collector = MESSAGE.createMessageComponentCollector({ iFilter: interaction => interaction.user.id });

        collector.on('collect', async (lucas) => {
            if (lucas.customId === 'verifurl') {
                const id = lucas.user.id;
                await lucas.deferReply({ ephemeral: true });

                if (cooldowns.has(id)) {
                    const expirationTime = cooldowns.get(id);
                    if (Date.now() < expirationTime) {
                        const timeLeft = Math.ceil((expirationTime - Date.now()) / 1000);
                        return lucas.editReply({ content: `${lucas.user} Você só poderá tentar verificar novamente em **${timeLeft} segundos!**`, ephemeral: true });
                    } else {
                        cooldowns.delete(id); 
                    }
                }

                cooldowns.set(id, Date.now() + 15000);

                await axios.get(`https://discord.com/users/user/${id}`).then(async function (database) {
                    let sobremim = database.data.profile.aboutMe;

                    if (sobremim !== null && cargos && (sobremim.toLowerCase().includes(`teste`) || sobremim.toLowerCase().includes(`/teste`) || sobremim.toLowerCase().includes(`dsc.gg/bianchis`))) {
                        const member = lucas.guild.members.cache.get(lucas.user.id);
                        await member.roles.add(cargos, "Sistema de URL personalizada");
                        await lucas.editReply({ content: `${lucas.user} Parabéns, você foi verificado com sucesso!`, ephemeral: true });

                        const sucessoEmbed = new Discord.EmbedBuilder()
                            .setAuthor({ name: `${lucas.guild} - URL na bio!`, iconURL: lucas.guild.iconURL() })
                            .setTitle("Um novo membro colocou a URL do servidor na bio!")
                            .setDescription(`Membro: <@${lucas.user.id}> \`(${lucas.user.id})\`\nCargo Recebido: <@&${cargos}> \`(${cargos})\``)
                            .setTimestamp()
                            .setFooter({ text: `Powered by ${client.user.username}`, iconURL: `${lucas.client.user.displayAvatarURL({ display: true, size: 4096 })}` });

                        await client.channels.cache.get(idcanallogs).send({embeds: [sucessoEmbed]});
                    } else {
                        await lucas.editReply({ content: `${lucas.user} Utilize alguma das URL em sua bio para receber o cargo!`, ephemeral: true });
                    }
                });
            }
        });
    }
};