const Discord = require("discord.js");

module.exports = {
    name: 'configurar',
    description: '.',
    default_member_permissions: 0,
    options: [
        {
            name: "sistema",
            description: ".",
            type: Discord.ApplicationCommandOptionType.SubcommandGroup,
            options: [
                {
                    name: "dj",
                    description: "Configurar sistema de dj para o bot.",
                    type: Discord.ApplicationCommandOptionType.Subcommand
                }
            ]
        }
    ],
    exec: async ({client, interaction}) => {
        const serverDB = await client.dbGuild.findOne({ _id: interaction.guild.id })

        if(!serverDB.music.admPermToUse){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, não sou autorizado a poder usar meus comandos de musica neste servidor.`, iconURL: client.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        const guildDb = async ()=> await client.dbGuild.findOne({ _id: interaction.guild.id }) || await client.dbGuild.create({ _id: interaction.guild.id })

        const cancelButton = new Discord.ActionRowBuilder()
        .addComponents(
            new Discord.ButtonBuilder()
            .setCustomId(`cancel`)
            .setEmoji("<:X_:1151936937540726905>")
            .setLabel('Cancelar')
            .setStyle(Discord.ButtonStyle.Secondary),
        );

        const generateMessage = async() =>{
            const databaseOfGuild = await guildDb()
            const roleSet = interaction.guild.roles.cache.get(databaseOfGuild.music.dj.role)

            const embedConfigRegistry = new Discord.EmbedBuilder()
            .setAuthor({ name: `Configurar sistema de dj em ${interaction.guild.name}`, iconURL: interaction.guild.iconURL()})
            .addFields(
                {
                    name: `> **Sistema ativo:**`,
                    value: databaseOfGuild.music.dj.active && roleSet ? "`✅ Ativo`" : "`❌ Desativado`",
                    inline: true
                },
                {
                    name: `> **Cargo do registro:**`,
                    value: `${databaseOfGuild.music.dj.role ? `${roleSet || "`Cargo deletado`"}` : "`Sem cargo`"}`,
                    inline: true
                },
            )
            .setColor(client.config.mainColor);
            
            const buttonsConfigRegistry = new Discord.ActionRowBuilder()
            .addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId("active/desactive")
                    .setLabel(databaseOfGuild.music.dj.active && roleSet ? "Desativar" : "Ativar")
                    .setEmoji(databaseOfGuild.music.dj.active && roleSet ? "<:OnBlue:1152616795350499458>" : "<:Off:1149308391324401674>")
                    .setDisabled(!roleSet)
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`setRole`)
                    .setEmoji("<:Member:1150639703658352760>")
                    .setLabel('Setar Cargo')
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`reset`)
                    .setLabel('Resetar Sistema')
                    .setEmoji("<:Reset:1149309446904877097>")
                    .setStyle(Discord.ButtonStyle.Danger),
            );

            return { embeds: [embedConfigRegistry], components: [buttonsConfigRegistry], fetchReply: true, ephemeral: true }
        }
            
        interaction.reply(await generateMessage()).then(msg=>{
            
            const collector = msg.createMessageComponentCollector({ idle: 1000 * 60 * 5 });

            collector.on('collect', async i => {
                if(i.isButton()){
                    const { customId: Button } = i

                    if(Button == "cancel"){
                        i.update(await generateMessage())
                    }
                    if(Button == "reset"){
                        await client.dbGuild.updateOne({ _id: i.guild.id },{
                            $set:{
                                "music.dj": {}
                            }
                        })
                        i.update(await generateMessage())
                    }
                    if(Button == "setRole"){
                        const rolesRow = new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.RoleSelectMenuBuilder()
                            .setCustomId(Button)
                            .setPlaceholder("Selecione um cargo para setar.")
                        )
                        i.update({ components: [rolesRow, cancelButton]})
                    }

                    if(Button == "active/desactive"){
                        const databaseOfGuild = await guildDb()
                        if(databaseOfGuild.music.dj.active){
                            await client.dbGuild.updateOne({ _id: i.guild.id },{
                                $set:{
                                    "music.dj.active": false
                                }
                            })
                            i.update(await generateMessage())
                        } else {
                            await client.dbGuild.updateOne({ _id: i.guild.id },{
                                $set:{
                                    "music.dj.active": true
                                }
                            })
                            i.update(await generateMessage())
                        }
                        
                    }
                }
                if(i.isRoleSelectMenu()){
                    const role = i.guild.roles.cache.get(i.values[0])
                    if(!role || role.comparePositionTo(interaction.guild.members.me.roles.highest) >= 0 || role.tags?.botId){
                        return i.reply({ content: `O cargo selecionado não pode ser adicionado por ser de um bot ou estar acima do meu.`, ephemeral: true})
                    }
                    await client.dbGuild.updateOne({ _id: i.guild.id },{
                        $set:{
                            "music.dj.role": role.id
                        }
                    })
                    i.update(await generateMessage())
                }
            });

        })
    }
}


