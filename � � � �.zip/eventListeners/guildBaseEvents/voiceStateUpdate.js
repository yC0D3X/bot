const { AuditLogEvent, EmbedBuilder } = require("discord.js");

const counts = new Map()

module.exports = {
    once: false,
    eventName: "voiceStateUpdate",
    exec: async (client, oldState, newState) => {
        if(newState.channel) return;

        const serverDB = await client.dbGuild.findOne({ _id: oldState.guild.id })
        if(!serverDB || !serverDB.removedCallLog.active) return;

        newState.guild.fetchAuditLogs()
        .then(async audit=>{
            const lastAudit = audit.entries.first()
            if(lastAudit.action != AuditLogEvent.MemberDisconnect) return;
            let AuditInMap = counts.get(lastAudit.id) || 0
            if(!AuditInMap) counts.set(lastAudit.id, 0);
            if(AuditInMap >= lastAudit.extra.count) return;
            const Adm = await client.users.fetch(lastAudit.executorId)
            const user = await client.users.fetch(newState.id)
            
            const channelLogs = client.channels.cache.get(serverDB.removedCallLog.channel)
            channelLogs?.send({
            embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `${user.id}`, iconURL: user.avatarURL() })
                .setTitle(`👤 Membro removido da call:`)
                .setColor(client.config.mainColor)
                .setDescription(`> Membro: 
                \`\`\`${user.username}\`\`\`
                > **Adm:**
                \`\`\`${Adm.username}\`\`\`
                > **De:**
                \`\`\`${oldState.channel.name}\`\`\`
                `)
                .setTimestamp()
            ]
            })
            counts.set(lastAudit.id, ++AuditInMap)
        })
    }
}