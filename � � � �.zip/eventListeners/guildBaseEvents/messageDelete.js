const { EmbedBuilder } = require("discord.js")

module.exports = {
    once: false,
    eventName: "messageDelete",
    exec: async (client, message) => {
        const serverDB = await client.dbGuild.findOne({ _id: message.guild.id })
        if(!serverDB || !serverDB.messagesLogs.active) return;

        const channelLogs = client.channels.cache.get(serverDB.messagesLogs.channel)

        channelLogs?.send({
        embeds: [
            new EmbedBuilder()
            .setAuthor({ name: `${message.author.username}(${message.author.id})`, iconURL: message.author.avatarURL() })
            .setTitle(`📑 Mensagem de texto deletada:`)
            .setColor(client.config.mainColor)
            .setDescription(`> **Canal de texto:** ${message.channel} 
            ${message.content && `\n> **Mensagem:**
            \`\`\`${message.content}\`\`\``
            }
            ${message.attachments.size 
                ?  `> **Arquivos anexados:**
                ${[...message.attachments.values()]
                    .map((attachment, i) => `${++i}. ${attachment.url}`)
                    .join("\n")
                }`
                :  ``
             }
            `)
            .setTimestamp()
        ]
       })
    }
}