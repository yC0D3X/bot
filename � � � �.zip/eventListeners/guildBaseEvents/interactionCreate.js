const { EmbedBuilder, ChannelType, PermissionFlagsBits, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require("discord.js");

module.exports = {
    once: false,
    eventName: "interactionCreate",
    exec: async (client, interaction) => {
        // Executor de comandos
        if (interaction.isCommand()) {
            const { commandName } = interaction;
            const command = client.loader.commands.find(cmd => cmd.name == commandName);
            interaction["member"] = interaction.guild.members.cache.get(interaction.user.id)
            if(command) command.exec({ client, interaction });
        } 
        
        //AutoCompleteSystem
        if(interaction.isAutocomplete()){
            const { commandName } = interaction;
            const command = client.loader.commands.find(cmd => cmd.name == commandName);
            command?.autoCompleteRun(interaction) 
        }

        //Registro
        if(interaction.isButton()){
            const { customId: Button } = interaction
            const guildDb = await client.dbGuild.findOne({ _id: interaction.guild.id })
            if(Button == "register"){
                if(!guildDb.register.active){
                    return interaction.reply({ content: "Sistema de registro desativado, por favor entre em contato com os adiministrados para mais informações.", ephemeral: true })
                }

                const modal = new ModalBuilder()
                .setCustomId('registryModal')
                .setTitle('Registro');

                const name = new TextInputBuilder()
                    .setCustomId('name')
                    .setLabel("Nome:")
                    .setPlaceholder("Digite seu nome")
                    .setMaxLength(12)
                    .setRequired(true)
                    .setStyle(TextInputStyle.Short);

                const surname = new TextInputBuilder()
                    .setCustomId('surname')
                    .setLabel("Sobrenome")
                    .setMaxLength(12)
                    .setPlaceholder("Digite seu sobrenome")
                    .setRequired(true)
                    .setStyle(TextInputStyle.Short);

                const id = new TextInputBuilder()
                    .setCustomId('id')
                    .setLabel("Qual seu RG?")
                    .setPlaceholder("Digite seu id")
                    .setMaxLength(6)
                    .setRequired(true)
                    .setStyle(TextInputStyle.Short);

                const nameRow = new ActionRowBuilder().addComponents(name);
                const surnameRow = new ActionRowBuilder().addComponents(surname);
                const idRow = new ActionRowBuilder().addComponents(id);

                modal.addComponents(nameRow, surnameRow, idRow);

                await interaction.showModal(modal);
            }
        }
        if(interaction.isModalSubmit()){
            const { customId: Modal } = interaction
            if(Modal.startsWith("sayModalText")){
                const channelId = Modal.split("/")[1]
                const channel = interaction.guild.channels.cache.get(channelId)
                const message = interaction.fields.getTextInputValue('Mensagem');
                if(message.length > 2000){
                  const splitedText = message.split("\n")
                  const splitedTextLength = Math.floor(splitedText.length / 2)
                  const firstMessage = splitedText.slice(0, splitedTextLength).join("\n")
                  const secondMessage = splitedText.slice(splitedTextLength).join("\n")
        
                  if(firstMessage.length > 2000 || secondMessage.length > 2000){
                    const splitedText = message.split(" ")
                    const splitedTextLength = Math.floor(splitedText / 2)
                    const firstMessage = splitedText.slice(0, splitedTextLength).join(" ")
                    const secondMessage = splitedText.slice(splitedTextLength).join(" ")
        
                    if(firstMessage.length > 2000 || secondMessage.length > 2000){
                      const splitedText = message
                      const splitedTextLength = Math.floor(splitedText.length / 2)
                      const firstMessage = splitedText.slice(0, splitedTextLength)
                      const secondMessage = splitedText.slice(splitedTextLength)
        
                      if(firstMessage.length > 2000 || secondMessage.length > 2000){
                        return await interaction.reply({ content: 'Ocorreu um erro colossal, não consegui dividir este texto de maneira alguma', ephemeral: true });
                      } else {
                        await channel.send({ content: firstMessage });
                        await channel.send({ content: secondMessage });
                      }
                      
                    } else {
                      await channel.send({ content: firstMessage });
                      await channel.send({ content: secondMessage });
                    }
        
                    
                  } else {
                    await channel.send({ content: firstMessage });
                    await channel.send({ content: secondMessage });
                  }
        
                } else {
                  await channel.send({ content: message });
                }
          
                await interaction.reply({ content: 'Mensagem enviada com sucesso!', ephemeral: true });
            }

            if(Modal == "registryModal"){
                const name = interaction.fields.getTextInputValue('name');
                const surname = interaction.fields.getTextInputValue('surname');
                const id = interaction.fields.getTextInputValue('id');

                const guildDb = await client.dbGuild.findOne({ _id: interaction.guild.id })

                if(isNaN(id)){
                    return interaction.reply({ content: "Por favor digite um id valido.", ephemeral: true })
                }
                if((await interaction.guild.members.fetch()).find(member => member.nickname?.endsWith(`- ${id}`))){
                    return interaction.reply({ content: "Ja tem algum usuário utilizando este id, verifique se você digitou certo ou entre em contato com os adiministrados para mais informações.", ephemeral: true })
                }

                const role = interaction.guild.roles.cache.get(guildDb.register.role)
                if(!role){
                    await client.dbGuild.updateOne({ _id: interaction.guild.id}, {
                        register: {}
                    })
                    return interaction.reply({ content: `Não foi possivel liberar fazer seu registro pois o cargo pré-configurado foi removido pelos administradores, por favor entre em contato com a staff par aque eles resolvam este problema.`, ephemeral: true })
                }
                interaction.member.roles.add(guildDb.register.role).catch(e=>{
                    console.log(`Erro ao dar o cargo de registro para ${interaction.user.username}(${interaction.user.id}) pelo erro: ${e}`)
                })
                const newNick = `${name} ${surname} - ${id}`

                setNick()

                async function setNick(){
                        interaction.member.setNickname(newNick, "Registro no servidor.").then(async ()=>{
                            const newMember = await interaction.guild.members.fetch(interaction.member.id)
                            newMember.nickname != newNick && await setNick()
                        }, err=>{
                            console.log(`Erro ao setar nickname de ${interaction.user.username}(${interaction.user.id}) pelo erro: ${err}`)
                        })     
                }
                interaction.reply({ content: `Seu registro foi feito com sucesso, fique avontade para usufruir do servidor!`, ephemeral: true })
            }
        }
        
    }
}

