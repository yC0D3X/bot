const { EmbedBuilder, PermissionFlagsBits, ApplicationCommandOptionType } = require("discord.js");

module.exports = {
    name: 'unlock',
    description: 'Abrir o servidor ou o canal',
    default_member_permissions: [PermissionFlagsBits.ManageGuild],
    options: [
        {
            name: "alvo",
            description: "Selecione o que deseja abrir",
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: "Servidor",
                    value: "server"
                },
                {
                    name: "Canal",
                    value: "channel"
                }
            ]
        }
    ],
    exec: async ({ client, interaction }) => {
        const target = interaction.options.getString("alvo")

        if(target == "server"){
            const role = interaction.guild.roles.everyone
            const permissions = role.permissions.toArray()
            if(role.permissions.has(PermissionFlagsBits.SendMessages)){
                interaction.reply({ embeds: [
                    new EmbedBuilder()
                    .setAuthor({ name: `🔓 Unlock...`, iconURL: interaction.guild.iconURL()})
                    .setColor(client.config.mainColor)
                    .setDescription(`> **O servidor ja está aberto**`)
                    .setTimestamp()
                ] , ephemeral: true })
            } else {
                permissions.push("SendMessages")
                await role.edit({ permissions })
                interaction.reply({ embeds: [
                    new EmbedBuilder()
                    .setAuthor({ name: `Lockdown!`, iconURL: interaction.guild.iconURL()})
                    .setColor(client.config.mainColor)
                    .setDescription(`> **O servidor foi aberto com sucesso!**`)
                    .setTimestamp()	
                ] , ephemeral: true })
            }
        } else {
            const role = interaction.channel.permissionsFor(interaction.guild.roles.everyone)
            if(role.has(PermissionFlagsBits.SendMessages)){
                interaction.channel.permissionOverwrites.create(interaction.channel.guild.roles.everyone, { SendMessages: true });
                interaction.reply({ embeds: [
                    new EmbedBuilder()
                    .setAuthor({ name: `🔓 Unlock...`, iconURL: interaction.guild.iconURL()})
                    .setColor(client.config.mainColor)
                    .setDescription(`> **Canal aberto com sucesso!**`)
                    .setTimestamp()
                ] , ephemeral: true })
            } else {
                interaction.reply({ embeds: [
                    new EmbedBuilder()
                    .setAuthor({ name: `🔓 Unlock!`, iconURL: interaction.guild.iconURL()})
                    .setColor(client.config.mainColor)
                    .setDescription(`> **O Canal ja está aberto**`)
                    .setTimestamp()
                ] , ephemeral: true })
            }
        }
    }
}