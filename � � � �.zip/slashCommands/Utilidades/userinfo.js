const { PermissionFlagsBits, ApplicationCommandOptionType, EmbedBuilder } = require("discord.js");

module.exports = {
    name: 'userinfo',
    description: 'Pegar informações de um usuário.',
    options: [
        {
            name: "usuário",
            description: "Quem você deseja pegar informações.",
            type: ApplicationCommandOptionType.User,
            required: false
        }
    ],
    exec: async ({client, interaction}) => {
        let user = interaction.options.getUser("usuário") || interaction.user

        const embed = new EmbedBuilder()
        .setTitle(`${user.displayName}`)
		.setURL(`https://discord.com/users/${user.id}`)
		.setAuthor({ name: 'Informações de Usuário'})
        .setThumbnail(user.avatarURL())
        .setColor(client.config.mainColor)
        .addFields(
            {
                name: `**<:hdev_user:1151584770107645995> Tag do Discord**`,
                value: `\`\`\`@${user.username}\`\`\``,
				inline: true,
            },
			{
                name: `**<:hdev_id:1151585277136085043> ID do discord**`,
                value: `\`\`\`${user.id}\`\`\``,
				inline: true,
            },
            {
                name: `**<:hdev_calendar:1151584706073215026> Conta criada**`,
                value: `${user.createdAt.toLocaleString("pt-BR")}`,
				inline: false,
            }
        )
        .setTimestamp()

        interaction.reply({ embeds: [embed], ephemeral: true})
    }
}