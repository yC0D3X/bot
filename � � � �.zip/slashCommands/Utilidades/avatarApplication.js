const Discord = require("discord.js");

module.exports = {
  name: "Ver Avatar",
  type: Discord.ApplicationCommandType.User,
  dm_permission: false,
  exec: async ({client, interaction}) => {
    const user = interaction.targetUser
    
    const embed = new Discord.EmbedBuilder()
    .setColor(client.config.mainColor)
    .setTitle(`> Avatar de ${user.username}`)
    .setImage(user.avatarURL({ size: 2048, extension: "png"}))
    .setFooter({ text: `${client.user.username} | Todos Direitos Reservados`})

	let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                .setURL(user.avatarURL({ size: 2048, extension: "png"}))
                .setLabel('Baixar imagem')
                .setEmoji("<:hdev_download:1181491713345343508>")
                .setStyle(Discord.ButtonStyle.Link)
    )
  
    interaction.reply({ embeds: [embed] , components: [row], ephemeral: true })
  }
}