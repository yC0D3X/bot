const Discord = require("discord.js");
const discordTranscripts = require('discord-html-transcripts');

const permissions =  [
  Discord.PermissionFlagsBits.ViewChannel,
  Discord.PermissionFlagsBits.SendMessages,
  Discord.PermissionFlagsBits.AttachFiles,
  Discord.PermissionFlagsBits.AddReactions,
]

module.exports = {
    generateMenuRow,
    once: false,
    eventName: "interactionCreate",
    exec: async (client, interaction) => {
        const { Ticket } = client.config
        const { menus } = Ticket
        const options = menus.map(menu => menu.opções).flat()

        if(interaction.isStringSelectMenu() && interaction.values[0].startsWith("menuChoice")){
            if(interaction.member.roles.cache.has(client.config.Ticket.blackListRole)) return interaction.editReply({ content: 'Você **não** pode mais abrir ticket!', ephemeral: true });
            
            const [ , indice] = interaction.values[0].split(":")
            
            const parent = options[indice].categoria || Ticket.categoriaDefault
            const name = `${options[indice].nameChannelEmoji}・${interaction.member.nickname ? interaction.member.nickname : user.username}`
            
            await interaction.message.edit({ components: interaction.message.components })
         
            const haveChannel = interaction.guild.channels.cache.find(canal => canal.parent == parent && canal.topic?.split(" ")[0] == interaction.user.id && canal.name == name.toLocaleLowerCase())
            if(haveChannel) return interaction.reply({ embeds: [new Discord.EmbedBuilder()
              .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
              .setThumbnail(interaction.guild.iconURL())
              .setColor(client.config.mainColor)
              .setDescription(`> Você já tem um ticket aberto no servidor... Clique no botão abaixo para ir até ele.`)
            ], components: [createButtonLink(haveChannel.url)], ephemeral: true})
          
            const assunto = new Discord.TextInputBuilder()
                    .setCustomId('assunto')
                    .setLabel("Qual é o assunto do ticket.")
                    .setPlaceholder("Digite o assunto que será tratado no ticket.")
                    .setRequired(true)
                    .setMaxLength(150)
                    .setStyle(Discord.TextInputStyle.Short);
          
            const modal = new Discord.ModalBuilder()
                      .setCustomId(`CreateChannel/${name}/${parent}/${indice}`)
                      .setTitle(`Sistema de Ticket | ${client.user.username}`)
                .addComponents(
                  new Discord.ActionRowBuilder()
                  .addComponents(assunto)
                );
          
              interaction.showModal(modal);
            } 
          
            if(interaction.isModalSubmit()){
              const { customId: modal } = interaction
              
              if(modal.startsWith("CreateChannel")){
                const assunto = interaction.fields.getTextInputValue('assunto');
                const [, name, parent, indice] = modal.split("/")
                
                const menuSelected = client.config.Ticket.menus.find(menu=> menu.opções.find(op => name.startsWith(op.nameChannelEmoji)))

                interaction.guild.channels.create({
                  name,
                  parent,
                  topic: interaction.user.id,
                  permissionOverwrites: [
                    {
                      id: interaction.guild.id,
                      deny: permissions
                    },
                    {
                      id: interaction.user.id,
                      allow: permissions
                    },
                    ...menuSelected.suportRoles.map(role=>{
                        return {
                            id: role,
                            allow: permissions
                          }
                    })
                 ],
                }).then(channel=>{
                  interaction.reply({embeds: [new Discord.EmbedBuilder()
                    .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                    .setThumbnail(interaction.guild.iconURL())
                    .setColor(client.config.mainColor)
                    .setDescription(`> Seu Ticket foi criado com sucesso! Clique no botão abaixo para ir até ele.`)
                  ], components: [createButtonLink(channel.url)], ephemeral: true})
                
                  channel.send({ embeds: [
                    new Discord.EmbedBuilder()
                    .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                    .setThumbnail(interaction.guild.iconURL())
                    .setColor(client.config.mainColor)
                    .setDescription(`> ・**Olá ${interaction.user}, bem vindo ao seu ticket.**
          
                    > <:hdev_equipe:1161117088543424583>・**Equipe Responsável:** ${menuSelected.suportRoles.map(role=> `<@&${role}>`)}
                    
                    > <:hdev_cronometro:1160919847073488947>・**Aguarde** por favor, logo será **atendido!**
                    
                    > <:hdev_editar:1160919781717848206>・**Assunto:** \`\`${assunto}\`\``)
                  ], components: [generateMenuRow()] })
                  
                  menuSelected.suportRoles.forEach(role=>{
                    interaction.guild.roles.cache.get(role)?.members.forEach(async member=>{
                        const embed = new Discord.EmbedBuilder()
                        .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                        .setThumbnail(interaction.guild.iconURL())
                        .setColor(client.config.mainColor)
                        .setDescription(`> \`${interaction.user.username}(${interaction.user.id})\` Abriu um ticket, vá responde-lo!`)

                        const userDb = await client.dbUser.findById(member.id)
                        if(!userDb || userDb?.dmMessages.ticket){
                          member.send({ embeds: [embed], components: [createButtonLink(channel.url)] }).catch(e=>{
                            member.send({ embeds: [embed], components: [createButtonLink(channel.url)] }).catch(e=>{})
                          })
                        }

                      })
                  })
                  
                  sendLog(`> Ticket: \`\`\`${channel.name}\`\`\`\n> Foi **aberto** por: \`\`\`${interaction.user.username} (${interaction.user.id})\`\`\``, { components: [createButtonLink(channel.url)]}, interaction, client)
                })
          
              }
            }
              
            if(interaction.isStringSelectMenu()){
              const [ select ] = interaction.values
          
              if(select == "closeTicket"){
                const { channel } = interaction
                
                if(!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageChannels)) return interaction.reply({ embeds: [new Discord.EmbedBuilder()
                  .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                  .setThumbnail(interaction.guild.iconURL())
                  .setColor(client.config.mainColor)
                  .setDescription(`> Você não tem permissão para usar esta função, peça a um adm utiliza-la se for necessário.`)
                ], ephemeral: true })
          
                if(channel.parent == Ticket.categoriaTicketsCloseds) return interaction.reply({ embeds: [new Discord.EmbedBuilder()
                  .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                  .setThumbnail(interaction.guild.iconURL())
                  .setColor(client.config.mainColor)
                  .setDescription(`> Calma ae chefe... Este ticket já está fechado...`)
                ], ephemeral: true })
                channel.setParent(Ticket.categoriaTicketsCloseds)
          
                interaction.update({ components: [] })
          
                const button = new Discord.ActionRowBuilder().addComponents(
                  new Discord.ButtonBuilder()
                    .setCustomId("reopenTicket")
                    .setLabel("Reabrir Ticket")
                    //.setEmoji(Emojis.sakuraBlack)
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId("deleteTicket")
                    .setLabel("Excluir Ticket")
                    //.setEmoji(Emojis.sakuraBlack)
                    .setStyle(Discord.ButtonStyle.Secondary)
                );
          
                interaction.channel.send({ embeds: [new Discord.EmbedBuilder()
                  .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                  .setThumbnail(interaction.guild.iconURL())
                  .setColor(client.config.mainColor)
                  .setDescription(`> Para reabrir o ticket ou exclui-lo, use os botões abaixo:`)
                ], components: [button] })
                sendLog(`> Ticket: \`\`\`${interaction.channel.name}\`\`\`\n> Foi **fechado** por: \`\`\`${interaction.user.username} (${interaction.user.id})\`\`\``, { components: [createButtonLink(interaction.channel.url)]}, interaction, client)
              }
              if(select == "memberAdd"){
                await interaction.update({ components: [generateMenuRow()]})
                const { channel } = interaction
          
                if(!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageChannels)) return interaction.followUp({ embeds: [new Discord.EmbedBuilder()
                  .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                  .setThumbnail(interaction.guild.iconURL())
                  .setColor(client.config.mainColor)
                  .setDescription(`> Você não tem permissão para usar esta função, peça a um adm utiliza-la se for necessário.`)
                ], ephemeral: true })
                
                const message = await interaction.channel.send({embeds: [new Discord.EmbedBuilder()
                  .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                  .setThumbnail(interaction.guild.iconURL())
                  .setColor(client.config.mainColor)
                  .setDescription(`> Digite o id, ou marque o usuário que deseja adicionar ao ticket:`)
                ]})
          
                const collector = channel.createMessageCollector({ filter: i => i.author.id == interaction.user.id, idle: 1000 * 60 * 10})
            
                collector.on("collect", async m =>{
                  const user = interaction.guild.members.cache.get(m.content.replace(/\D/g, ""))
                  if(!user){
                    m.reply("Apenas mencione o usuario desejado agora...").then(ms=>{
                      setTimeout(()=>{ m.delete(), ms.delete() }, 2000)
                    })
                  } else if(interaction.channel.topic.includes(user?.id)){
                      m.reply("Usuário ja está no Ticket... Encerrando função...").then(ms=>{
                      setTimeout(()=>{ m.delete(), ms.delete(), message.delete(), collector.stop() }, 3000)
                    })
                  } else {
                    m.delete()
                    collector.stop()
                    m.channel.permissionOverwrites.create(user.id, {
                      SendMessages: true,
                      ViewChannel: true,
                      AttachFiles: true,
                      AddReactions: true
                    })
          
                    message.edit({embeds: [new Discord.EmbedBuilder()
                      .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                      .setThumbnail(interaction.guild.iconURL())
                      .setColor(client.config.mainColor)
                      .setDescription(`> **${user.user.username || "Desconhecido"}** foi adicionado(a) ao ticket.`)
                    ]}).then(msg=>{
                      setTimeout(()=>{
                        msg.delete().catch(e=>{})
                      }, 6000)
                    })
                    sendLog(`> Usuário: \`\`\`${user.user.username} (${user.user.id})\`\`\`\n> Foi **adicionado** ao ticket: \`\`\`${interaction.channel.name}\`\`\`\n> Por: \`\`\`${interaction.user.username} (${interaction.user.id})\`\`\` `, { components: [createButtonLink(interaction.channel.url)]}, interaction, client)
                  }
                })
              }
          
              if(select == "memberRemove"){
                await interaction.update({ components: [generateMenuRow()]})
          
                if(!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageChannels)) return interaction.followUp({ embeds: [new Discord.EmbedBuilder()
                  .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                  .setThumbnail(interaction.guild.iconURL())
                  .setColor(client.config.mainColor)
                  .setDescription(`> Você não tem permissão para usar esta função, peça a um adm utiliza-la se for necessário.`)
                ], ephemeral: true })
                
                const membersTicket = interaction.channel.permissionOverwrites.cache.filter(perm=> interaction.channel.topic != perm.id && perm.type == 1 )
          
                if(!membersTicket.size) return interaction.followUp({ embeds: [new Discord.EmbedBuilder()
                  .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                  .setThumbnail(interaction.guild.iconURL())
                  .setColor(client.config.mainColor)
                  .setDescription(`> Nenhum usuário foi adicionado ao ticket ainda.`)
                ], ephemeral: true})
          
                const menu = new Discord.ActionRowBuilder()
                .addComponents(
                  new Discord.StringSelectMenuBuilder()
                    .setCustomId('select')
                    .setPlaceholder(`Selecione um membro`)
                    .addOptions(membersTicket.map(member=>{
                      return {
                        label: client.users.cache.get(member.id).username || "Saiu do servidor#0000",
                        value: "RemoveTicket/" + member
                      }
                    }))
                );
          
                interaction.followUp({ embeds: [new Discord.EmbedBuilder()
                  .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                  .setThumbnail(interaction.guild.iconURL())
                  .setColor(client.config.mainColor)
                  .setDescription(`> Selecione o membro que deseja remover do ticket:`)
                ], components: [menu], ephemeral: true})
              }
          
              if(select.startsWith("RemoveTicket/")){
                const [ , memberId] = select.split("/")
                const user = client.users.cache.get(memberId)
                interaction.channel.permissionOverwrites.delete(memberId, "Retirado do ticket")
                
                interaction.update({ embeds: [new Discord.EmbedBuilder()
                  .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                  .setThumbnail(interaction.guild.iconURL())
                  .setColor(client.config.mainColor)
                  .setDescription(`> Usuário removido com sucesso!`)
                ], components: []})
          
               sendLog(`> Usuário: \`\`\`${user.username || "Desconhecido"} (${user.id || ""})\`\`\`\n> Foi **removido** do ticket: \`\`\`${interaction.channel.name}\`\`\`\n> Por: \`\`\`${interaction.user.username} (${interaction.user.id})\`\`\` `, { components: [createButtonLink(interaction.channel.url)]}, interaction, client)
          
              }
            }
          
            if(interaction.isButton()){
              const { customId: button } = interaction
              if(button == "reopenTicket"){
                const ticketOwn = interaction.channel.topic
          
                if(!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageChannels)) return interaction.reply({ content: "Você não tem permissão para usar esta função, por favor peça a um adm.", ephemeral: true})
                
                const option = options.find(option=> interaction.channel.name.startsWith(option.nameChannelEmoji))
                const menuSelected = client.config.Ticket.menus.find(menu=> menu.opções.find(op => interaction.channel.name.startsWith(op.nameChannelEmoji)))
                
                interaction.channel.setParent(option.categoria ||  Ticket.categoriaDefault)
          
                interaction.channel.permissionOverwrites.set([
                  {
                    id: interaction.guild.id,
                    deny: permissions
                  },
                  {
                    id: ticketOwn,
                    allow: permissions
                  },
                  ...menuSelected.suportRoles.map(role=>{
                    return {
                        id: role,
                        allow: permissions
                      }
                    })
               ])
          
               interaction.message.delete()
               interaction.channel.send({ content: `<@${ticketOwn}>`, embeds: [new Discord.EmbedBuilder()
                .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                .setThumbnail(interaction.guild.iconURL())
                .setColor(client.config.mainColor)
                .setDescription(`> O ticket foi reaberto por: ${interaction.user}`)
              ]})
          
               const message = await interaction.channel.messages.fetch({ after: 1, limit: 1 }).catch(e=>{})
               message.first() && message.first().edit({ components: [generateMenuRow()]})
          
               sendLog(`> O ticket: \`\`\`${interaction.channel.name}\`\`\`\n> Foi **reaberto** por: \`\`\`${interaction.user.username} (${interaction.user.id})\`\`\``, { components: [createButtonLink(interaction.channel.url)]}, interaction, client)
              }
          
            if(button == "deleteTicket"){

              if(!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageChannels)) return interaction.reply({ embeds: [new Discord.EmbedBuilder()
                .setTitle(`<:hdev_bilhete:1161117990100680764> | Sistema De Ticket - ${client.user.username}`)
                .setThumbnail(interaction.guild.iconURL())
                .setColor(client.config.mainColor)
                .setDescription(`> Você não tem permissão para usar esta função, peça a um adm utiliza-la se for necessário.`)
              ], ephemeral: true })

              const attachment = await discordTranscripts.createTranscript(interaction.channel, {
                limit: -1, 
                returnType: 'attachment', 
                filename: `${interaction.channel.name}-transcript.html`, 
                saveImages: true, 
                poweredBy: false
              });
              interaction.channel.delete().catch(e=>{})
          
              sendLog(`> O ticket: \`\`\`${interaction.channel.name}\`\`\`\n> Foi **deletado** por: \`\`\`${interaction.user.username} (${interaction.user.id})\`\`\``,
               { files: [attachment] }, interaction, client)
          
              }
        }
    }
}

function generateMenuRow(){
    return new Discord.ActionRowBuilder()
          .addComponents(
            new Discord.StringSelectMenuBuilder()
              .setCustomId('select')
              .setPlaceholder(`Gerenciar Ticket`)
              .addOptions([
                {
                  label: "Fechar Ticket",
                  emoji: "<:hdev_cancelar:1160922757639446589>",  
                  value: "closeTicket"
                },
                {
                  label: "Adicionar membro",
                  emoji: "<:hdev_adicionarmembro:1161120075164692600>",
                  value: "memberAdd"
                },
                {
                  label: "Remover membro",
                  emoji: "<:hdev_removermembro:1161120087105876068>",
                  value: "memberRemove"
                }
              ])
          );
  }
  
  function createButtonLink(link){
    return new Discord.ActionRowBuilder().addComponents(
      new Discord.ButtonBuilder()
        .setLabel("Abrir ticket")
        .setStyle(Discord.ButtonStyle.Link)
        .setURL(link)
    );
  }
  
  function sendLog(description, options, interaction, client){
    client.channels.cache.get(client.config.Ticket.channelLog).send({ embeds: [new Discord.EmbedBuilder()
      .setTitle(`<:hdev_bilhete:1161117990100680764> | Log de Tickets - ${client.user.username}`)
      .setThumbnail(interaction.guild.iconURL())
      .setColor(client.config.mainColor)
      .setDescription(description)
      .setTimestamp()
    ], ...options}).catch(e=>{})
  }
