const { PermissionFlagsBits, ApplicationCommandOptionType, EmbedBuilder } = require("discord.js");

module.exports = {
    name: 'repeat',
    description: 'Ativar o repetir musica ou playlist',
    options: [
        {
            name: "alvo",
            description: "Em que deseja ativar o repeat",
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: "Música",
                    value: "music"
                },
                {
                    name: "Lista completa",
                    value: "queue"
                }
            ]
        }
    ],
    exec: async ({client, interaction}) => {
        const serverDB = await client.dbGuild.findOne({ _id: interaction.guild.id })

        if(!serverDB.music.admPermToUse){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, não sou autorizado a poder usar meus comandos de musica neste servidor.`, iconURL: client.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        if(interaction.member.voice.channel?.id != interaction.guild.members.me.voice.channel?.id){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, você deve estar na mesma call que eu para usar o comando.`, iconURL: client.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        if(serverDB 
            && serverDB.music.dj.active 
            && !interaction.member.roles.cache.has(serverDB.music.dj.role)
            && !interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, você não tem cargo de dj para usar o repeat.`, iconURL: interaction.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        const player = client.vulkava.players.get(interaction.guild.id);

        if(!player){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, eu não estou mais tocando música.`, iconURL: client.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        const choice = interaction.options.getString("alvo")
        choice == "music" ? player.setTrackLoop(!player.trackRepeat) : player.setQueueLoop(!player.queueRepeat)

        interaction.reply({ embeds: [
            new EmbedBuilder()
            .setAuthor({ name: `${choice == "music" 
            ? player.trackRepeat ? "Loop da música atual ativado." : "Loop da música atual desativado."
            : player.queueRepeat ? "Loop da fila atual ativado." : "Loop da fila atual desativado."
            }`, iconURL: interaction.guild.iconURL() })
            .setColor(client.config.mainColor)
          ]});
    }
}