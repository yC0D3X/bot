const { PermissionFlagsBits, ApplicationCommandOptionType, EmbedBuilder } = require("discord.js");

module.exports = {
    name: 'banmember',
    description: 'Banir um membro do servidor',
    default_member_permissions: [PermissionFlagsBits.BanMembers],
    options: [
        {
            name: "usuário",
            description: "Quem você deseja banir do servidor.",
            type: ApplicationCommandOptionType.User,
            required: true
        },
        {
            name: "motivo",
            description: "Motivo do ban.",
            type: ApplicationCommandOptionType.String,
            required: true
        },
    ],
    exec: async ({client, interaction}) => {
        const member = interaction.options.getMember("usuário")
        const reason = interaction.options.getString("motivo")
        try {
            member.ban({ reason })
            interaction.reply({ embeds: [new EmbedBuilder()
                .setAuthor({ name: `${member.id}`, iconURL: member.avatarURL() })
                .setTitle(`📑 Membro banido:`)
                .setColor(client.config.mainColor)
                .setDescription(`> **Membro:**
                \`\`\`${member.user.username}(${member.id})\`\`\`
                > **Banido por:**
               \`\`\`${interaction.user.username}(${interaction.user.id}\`\`\`
               `)
                .setTimestamp()]})
        } catch (error) {
            interaction.reply({ embeds: [new EmbedBuilder()
                .setAuthor({ name: `${member.id}`, iconURL: member.avatarURL() })
                .setTitle(`📑 Erro no Ban:`)
                .setColor(client.config.mainColor)
                .setDescription(`> **Ocorreu um erro ao tentar banir este membro, provavelmente eu não consigo bani-lo.** `)
                .setTimestamp()]})
        }
    }
}