const { Client } = require('discord.js-selfbot-v13');

module.exports = class selfBotClient extends Client {
    constructor(token){
        super();
        this.token = token
        this.fetchInProgress = true
        this.usersGets = []

        this.on('ready', async () => {
            console.log(`[SELFBOT] Iniciado em ${this.user.username} com sucesso.`);
            this.refreshUsers()
          })

        this.setMaxListeners(99)
    }

    start(){
        super.login(this.token).then(()=>{
            this.refreshUsers()
            setInterval(()=>{
                this.refreshUsers()
            }, 1000 * 60 * 60 * 24)
        }, err=>{
            console.log(`[SELFBOT] Token inválidado, gere outro para o sistema de Gifzada voltar a funcionar.`);
        });
    }

    refreshUsers(){
        const guilds = this.guilds.cache
        if(!guilds.size) return console.log(`[SELFBOT] cache de servidores vazio, selfbot caído.`);
        this.usersGets = []
        this.fetchInProgress = true
        const fetchsInProgress = {}

        guilds.forEach(guild=>{
            fetchsInProgress[guild.name] = true
            guild.members.fetch()
            .then(async members=>{
                const listMembers = members.map(async member=>{
                    const userObject = {
                        avatarURL: member.user.avatar ? member.user.displayAvatarURL({ dynamic: true, size: 2048, format: "png"}) : null,
                        userId: member.user.id,
                        guildId: guild.id,
                        bannerURL: null
                    }
                    if(userObject.avatarURL) return userObject
                })
                const listMembersResolve = (await Promise.all(listMembers)).filter(user => user)
                this.usersGets = [...this.usersGets, ...listMembersResolve]
                fetchsInProgress[guild.name] = false
                if(Object.values(fetchsInProgress).reduce((a,b)=> !a && !b, false)){
                    this.fetchInProgress = false
                    this.usersGets = filterArray(this.usersGets)
                    this.refreshUsersFetch()
                }
            }, err=>{
                console.log(err)
            })

        })
    }

    refreshUsersFetch(){
        const usersWithAnimateAvatar = this.usersGets.filter(user=> user.avatarURL.includes(".gif"))
        const usersWithNormalAvatar = this.usersGets.filter(user=> !user.avatarURL.includes(".gif"))

        const storeBanners = async user=>{
            this.guilds.cache.get(user.guildId)?.members.fetch({ user: user.userId, force: true }).then(({user})=>{
                if(user.banner){
                    this.usersGets.find(userGet=> userGet.userId == user.id).bannerURL = user.bannerURL({ dynamic: true, size: 2048, format: "png"})
                }
            }, err=>{ 
                if(String(err).includes("401: Unauthorized")){
                    console.log("[SELFBOT] Bot caído no meio da consulta de dados.")
                }
             })
        }

        usersWithAnimateAvatar.forEach(storeBanners)
        usersWithNormalAvatar.forEach(storeBanners)
    }
}

function filterArray(array){
    const uniqueItems = {};
    return array.filter(item => {
        return uniqueItems[item.userId] ? false : (uniqueItems[item.userId] = true);
    })
}
