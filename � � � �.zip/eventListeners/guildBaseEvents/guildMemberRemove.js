const { EmbedBuilder } = require("discord.js")

module.exports = {
    once: false,
    eventName: "guildMemberRemove",
    exec: async (client, member) => {
        
        const serverDB = await client.dbGuild.findOne({ _id: member.guild.id })
        if(!serverDB || !serverDB.outLogs.active) return;

        const channelLogs = client.channels.cache.get(serverDB.outLogs.channel)

        channelLogs?.send({
         embeds: [
             new EmbedBuilder()
             .setTitle(`<:hdev_user:1151584770107645995> Saiu do servidor:`)
             .setColor(client.config.mainColor)
             .setDescription(`> Membro: 
            \`\`\`${member.user.username}\`\`\`
            `)
			 .setThumbnail(member.displayAvatarURL())
			 .setFooter({ text: `ID: (${member.user.id})`})
             .setTimestamp()
         ]
        })
    }
}