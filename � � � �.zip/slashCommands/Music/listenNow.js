const { PermissionFlagsBits, ApplicationCommandOptionType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder } = require("discord.js");
const Canvas = require("canvas")
const { registerFont } = require('canvas')
registerFont('././src/util/Fonts/Geofont.ttf', { family: 'geologica' })

module.exports = {
    name: 'tocando',
    description: '.',
    options: [
        {
            name: "agora",
            description: "Ver a música que está tocando agora.",
            type: ApplicationCommandOptionType.Subcommand
        }
    ],
    exec: async ({client, interaction}) => {
        const serverDB = await client.dbGuild.findOne({ _id: interaction.guild.id })

        if(!serverDB.music.admPermToUse){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, não sou autorizado a poder usar meus comandos de musica neste servidor.`, iconURL: client.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        const player = client.vulkava.players.get(interaction.guild.id);
        if(!player){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, eu não estou tocando música.`, iconURL: client.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        await interaction.deferReply()

        let track = player.current
        track.metadata && (track = track.metadata)
        
        const timestampInitSound = client.lastTimestampsInitSound.get(interaction.guild.id)
        const calcRepeat = ~~(((timestampInitSound + track.duration) - Date.now()) / ~~(track.duration / 233))

        const canvas = Canvas.createCanvas(350, 365)
        const ctx = canvas.getContext("2d")

        const layout = await Canvas.loadImage("https://cdn.discordapp.com/attachments/663875775602098207/1196984851132338257/Background_components.png?ex=65b99e03&is=65a72903&hm=f6d21c508529593a3e41a7fd82a5d5162afef4cf8cfea2bf5fddc47c2501aa2e&")
        ctx.drawImage(layout, 0, 0, canvas.width, canvas.height)
        
        const progressBar = await Canvas.loadImage("https://cdn.discordapp.com/attachments/663875775602098207/1196991595875147876/progressBar.png?ex=65b9a44b&is=65a72f4b&hm=9230873265d621976e5b0c9f68a7df00c0ae7620f0acbde5fb13dbb533993ecb&")
        ctx.drawImage(progressBar, 59, 280, 233 - calcRepeat, progressBar.height)

        ctx.font = '16px geologica';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`${track.title.slice(0,33)}\n${track.title.slice(33,66).trim()}`,
        (canvas.width / 2) - (track.title.slice(0,33).length * 4.3),
         235)

        ctx.font = '12px geologica';
        ctx.fillText(transformSeconds(track.duration - ((timestampInitSound + track.duration) - Date.now())), 21, 287)
        ctx.fillText(transformSeconds(track.duration), 297, 287)
        
        ctx.save()

        ctx.beginPath();
        ctx.moveTo(94, 32);
        ctx.lineTo(256, 32);
        ctx.lineTo(256, 194);
        ctx.lineTo(94, 194);
        ctx.lineTo(94, 32);
        ctx.closePath(); 
        ctx.clip();

        const musicImage = await Canvas.loadImage(player.current.thumbnail)
        ctx.drawImage(musicImage, 30, 5, 290, 217)
        
        ctx.restore()

        const musicPlayers = {
            spotify: {
                iconURL: "https://cdn.discordapp.com/attachments/663875775602098207/1197009752803258449/Spotify_icon.png?ex=65b9b534&is=65a74034&hm=36ff0f985c40a1e4944260b4733f0f0816a34251b61884969005f73b4149eabe&",
                emoji: "<:Spotifyicon:1197002835515154473>"
            },
            youtube: {
                iconURL: "https://cdn.discordapp.com/attachments/663875775602098207/1196999790995718144/youtube.png?ex=65b9abed&is=65a736ed&hm=ce99e48031d3e1e6876d54547b7f575e29dc4a16d57345c22e4a537a576dfcaa&",
                emoji: "<:youtube:1197002832872755201>"
            },
            deezer: {
                iconURL: "https://cdn.discordapp.com/attachments/663875775602098207/1196999791213809785/Deezer.png?ex=65b9abed&is=65a736ed&hm=4ed8e5fbe53d1688858fee7cfcb1d461bf1b4f375a3af0f15a1a45ecab87e0fa&",
                emoji: "<:Deezer:1197008929964703794>"
            }
        }
        
        if(musicPlayers[track.source]){
        const musicPlayerIcon = await Canvas.loadImage(musicPlayers[track.source].iconURL)
        ctx.drawImage(musicPlayerIcon, 226, 165, musicPlayerIcon.width, musicPlayerIcon.height)
        }

        ctx.fillText(`${player.current.requester.globalName.length > 6 ? `${player.current.requester.globalName.slice(0,6)}...` : player.current.requester.globalName}`, 208, 332)
       
        ctx.beginPath();
        ctx.arc(183, 327, 16, 0, Math.PI * 2, true);
        ctx.closePath(); 
        ctx.clip();

        const requesterAvatar = await Canvas.loadImage(player.current.requester.avatarURL({ forceStatic: true, extension: "png"}))
        ctx.drawImage(requesterAvatar, 167, 311, 33, 33)

        const attachment = new AttachmentBuilder(canvas.toBuffer(), {name: 'listenNow.png'}) 

        interaction.followUp({ 
            files: [attachment],
            components: [
                new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                    .setLabel(`Abrir no ${track.source.slice(0,1).toUpperCase()}${track.source.slice(1)}`)
                    .setEmoji(musicPlayers[track.source].emoji || null)
                    .setStyle(ButtonStyle.Link)
                    .setURL(track.uri)
                )
            ]});
    }
}

function transformSeconds(sec){
    const segundosTotal = ~~(sec / 1000)
    const minutos = ~~(segundosTotal / 60)
    const segundos = segundosTotal % 60
    return [`${minutos}`, `${segundos}`].map(num => num.padStart(2,0)).join(":")
}