const { ActionRowBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ButtonBuilder, ButtonStyle} = require('discord.js');
const { generateMessageReminds, msgRemindsActives } = require('../../slashCommands/Utilidades/reminds');

let remindsActives = {}

module.exports = {
    readyUpReminds,
    once: false,
    eventName: "interactionCreate",
    exec: async (client, interaction) => {

        const cancelButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setCustomId("cancelRemindMsgConfig")
                .setLabel("Cancelar")
                .setStyle(ButtonStyle.Secondary)
            )

        async function remindsInRow(action){

            const userDb = await client.dbUser.findById(interaction.user.id) || await client.dbUser.create({ _id: interaction.user.id })

            const reminds = userDb.reminds.filter(remind => !remind.ended)
            
            const row = new ActionRowBuilder()
			        .addComponents(new StringSelectMenuBuilder()
                        .setCustomId('reminds')
                        .setPlaceholder(`Selecione o lembrete que deseja ${action}.`)
                        .addOptions(
                            reminds.map((remind, i)=>{
                                return new StringSelectMenuOptionBuilder()
                                    .setLabel(`Lembrete ${++i}:`)
                                    .setDescription(remind.remind.slice(0, 50))
                                    .setValue(`remind${action == "editar" ? "Edit" : "Delete"}/${remind.remind.slice(0,25)}`)
                            })
                        )
                    )

            return row
        }

        async function verifyRemindsActives(){
            const userDb = await client.dbUser.findById(interaction.user.id) || await client.dbUser.create({ _id: interaction.user.id })

            const reminds = userDb.reminds.filter(remind => !remind.ended)

            if(!reminds.length) return interaction.reply({ content: "Perdão, mas você não tem nenhum lembrete que esteja ativo.", ephemeral: true })
        }

        if(interaction.isButton()){
            const { customId: Button } = interaction

            if(["cancelRemindMsgConfig", "editRemind", "deleteRemind", "createRemind", "clearReminds"].includes(Button) && msgRemindsActives.get(interaction.user.id) != interaction.message.id){
                return interaction.reply({ content: "Perdão, essa mensagem de lembretes é antiga, por fazer dê o comando de novo.", ephemeral: true })
            }
            
            if(Button == "cancelRemindMsgConfig"){
                const message = await generateMessageReminds(client, interaction)
                await interaction.update({ embeds: [message.embed], components: [message.row] })
            }

            if(Button == "editRemind"){
                if(await verifyRemindsActives()) return;
                interaction.update({ components: [await remindsInRow("editar"), cancelButton] })
            }
            if(Button == "deleteRemind"){
                if(await verifyRemindsActives()) return;
                interaction.update({ components: [await remindsInRow("excluir"), cancelButton] })
            }
            if(Button == "clearReminds"){
                const userDb = await client.dbUser.findById(interaction.user.id) || await client.dbUser.create({ _id: interaction.user.id })

                const reminds = userDb.reminds.filter(remind => !remind.ended)

                userDb.reminds = reminds; await userDb.save();

                const message = await generateMessageReminds(client, interaction)
                await interaction.update({ embeds: [message.embed], components: [message.row] })
            }

            if(Button == "createRemind"){
                const modal = new ModalBuilder()
                    .setCustomId('createRemindModal')
                    .setTitle('Criar remind');

                const remindText = new TextInputBuilder()
                    .setCustomId('remindText')
                    .setLabel("O que deseja lembrar:")
                    .setMaxLength(950)
                    .setStyle(TextInputStyle.Paragraph);

                const remindTime = new TextInputBuilder()
                    .setCustomId('remindTime')
                    .setLabel("Tempo do remind")
                    .setPlaceholder("Ex: 1d 2h 3m 24s ou 11/12/2024 18:00:00 (Máx 24 Dias)")
                    .setMaxLength(50)
                    .setStyle(TextInputStyle.Short);

                const firstActionRow = new ActionRowBuilder().addComponents(remindText);
                const secondActionRow = new ActionRowBuilder().addComponents(remindTime);

                modal.addComponents(firstActionRow, secondActionRow);

                await interaction.showModal(modal);
            }

        }

        if(interaction.isStringSelectMenu()){
            const Menu = interaction.values[0]

            if(Menu.startsWith("remindEdit/")){
                const [, initRemind] = Menu.split("/")

                const userDb = await client.dbUser.findById(interaction.user.id) || await client.dbUser.create({ _id: interaction.user.id })

                const remind = userDb.reminds.filter(re=> re.remind.startsWith(initRemind))[0]

                const modal = new ModalBuilder()
                    .setCustomId(`editRemindModal/${remind._id}`)
                    .setTitle('Editar remind');

                const remindText = new TextInputBuilder()
                    .setCustomId('remindText')
                    .setLabel("O que deseja lembrar:")
                    .setValue(remind?.remind || "")
                    .setStyle(TextInputStyle.Paragraph);

                const remindTime = new TextInputBuilder()
                    .setCustomId('remindTime')
                    .setLabel("Tempo do remind")
                    .setPlaceholder("Ex: 1d 2h 3m 24s ou 11/12/2024 18:00:00")
                    .setValue(remind?.remindTimePass || "")
                    .setStyle(TextInputStyle.Short);

                const firstActionRow = new ActionRowBuilder().addComponents(remindText);
                const secondActionRow = new ActionRowBuilder().addComponents(remindTime);

                modal.addComponents(firstActionRow, secondActionRow);

                await interaction.showModal(modal);
            }

            if(Menu.startsWith("remindDelete/")){
                const [, content] = Menu.split("/")

                const userDb = await client.dbUser.findById(interaction.user.id) || await client.dbUser.create({ _id: interaction.user.id })

                const reminds = userDb.reminds.filter(re=> !re.remind.includes(content) )

                await client.dbUser.updateOne({
                    _id: interaction.user.id
                }, {
                    $set: {
                        reminds
                    }
                })

                const message = await generateMessageReminds(client, interaction)
                await interaction.update({ embeds: [message.embed], components: [message.row] })
                await interaction.followUp({ content: `Lembrete apagado com sucesso.`, ephemeral: true })
            }
        }

        if(interaction.isModalSubmit()){
            const { customId: Modal } = interaction

            if(Modal == "createRemindModal"){
	            createOrEditRemind()
            }

            if(Modal.startsWith("editRemindModal/")){
                const [, id] = Modal.split("/")
                createOrEditRemind(id)
            }
        }

        async function createOrEditRemind(id){
                const remindText = interaction.fields.getTextInputValue('remindText');
	            const remindTime = interaction.fields.getTextInputValue('remindTime');

                let remindTimeinMs;
                const dateToo = remindTime.split(" ")[0]?.split("/")?.reverse().join("/") + ` ${remindTime.split(" ")[1] || "00:00"}`
                const dateTo = new Date(dateToo)
                const timeTo = remindTime.split(" ").reduce((oVal, nVal)=> oVal + desabreviar(nVal), 0)

                if(dateTo == "Invalid Date"){
                    if(isNaN(timeTo) || remindTime.includes("/")){
                        id && await interaction.update({ components: interaction.message.components })
                        return interaction[id ? "followUp" : "reply"]({ content: `Infelizmente o tempo que você passou é inválido, tente seguir exatamente os exemplos no formulário existente.\n**Abaixo está o que você queria se lembrar para que não seja necessário reescrever:**
                        \`\`\`${remindText}\`\`\`
                        `, ephemeral: true })
                    } else {
                        remindTimeinMs = Date.now() + timeTo
                    }
                } else {
                    remindTimeinMs = dateTo.getTime()
                }

                if(remindTimeinMs - Date.now() > 2073600000){
                    id && await interaction.update({ components: interaction.message.components })
                    return interaction[id ? "followUp" : "reply"]({ content: `Perdão, mas eu tenho um limite de no máximo 24 Dias para salvar um lembrete.\n**Abaixo está o que você queria se lembrar para que não seja necessário reescrever:**
                    \`\`\`${remindText}\`\`\`
                    `, ephemeral: true })
                }

                if(remindTimeinMs < Date.now()){
                    id && await interaction.update({ components: interaction.message.components })
                    return interaction[id ? "followUp" : "reply"]({ content: `Infelizmente o tempo que você passou já passou... Tente um tempo mais recente.\n**Abaixo está o que você queria se lembrar para que não seja necessário reescrever:**
                    \`\`\`${remindText}\`\`\`
                    `, ephemeral: true })
                }

                if(id){
                    await client.dbUser.updateOne({
                        _id: interaction.user.id, "reminds._id": id
                    }, {
                        $set: {
                            "reminds.$.remind": remindText,
                            "reminds.$.remindTime": remindTimeinMs,
                            "reminds.$.remindTimePass": remindTime
                        }
                    })
                } else {
                    await client.dbUser.updateOne({
                        _id: interaction.user.id
                    }, {
                        $push: {
                            reminds: {
                                remind: remindText,
                                remindTime: remindTimeinMs,
                                remindTimePass: remindTime,
                                chatRemindCreated: interaction.channel.id,
                                ended: false
                            }
                        }
                    })
                }

                const message = await generateMessageReminds(client, interaction)
                await interaction.update({ embeds: [message.embed], components: [message.row] })
                await interaction.followUp({ content: `Lembrete ${id ? "editado" : "adicionado"} com sucesso!`, ephemeral: true })

                const userDb = await client.dbUser.findById(interaction.user.id)

                startRemid({
                    userId: interaction.user.id,
                    remind: remindText,
                    remindTime: remindTimeinMs,
                    chatRemindCreated: interaction.channel.id,
                    _id: userDb.reminds[userDb.reminds.length - 1]._id
                }, client)

        }

    }
}

function desabreviar(abbreviation) {
    const number = parseFloat(abbreviation.substr(0, abbreviation.length-1))
    const unit = abbreviation.substr(-1).toLowerCase()
    const zeros = { d:864e5, h:36e5, m:6e4, s:1e3 } 
    
    return !zeros[unit] ? abbreviation : number*zeros[unit]
}

async function startRemid(infos, client){
    const hasRemind = getUserReminds(infos.userId).find(remind=> remind.id == infos._id)

    if(hasRemind){
        clearTimeout(hasRemind.timeout)

        const reminds = getUserReminds(userId).filter(remind=> remind.id != infos._id)
        remindsActives[infos.userId] = reminds

        startRemindTime()
    } else {
        startRemindTime()
    }

    async function startRemindTime(){
        const user = await client.users.fetch(infos.userId).catch(e=>{})

        const awaitTime = setTimeout(async()=>{
            const embed = new EmbedBuilder()
            .setTitle(`<:hdev_calendar:1151584706073215026> | Lembretes! - ${user.username}`) 
            .setThumbnail(user.avatarURL())
            .setColor(client.config.mainColor)
            .setDescription(`> Opa!! Vim aqui te lembrar que: \`\`\`${infos.remind}\`\`\``)
            .setTimestamp()
 
            const userDb = await client.dbUser.findById(infos.userId)
            if(userDb.dmMessages.remind){
                user?.send({ embeds: [embed] }).catch(e=>{
                    client.channels.cache.get(infos.chatRemindCreated)?.send({ embeds: [embed], content: `${user}` }).catch(e=>{})
                })
            } else {
                client.channels.cache.get(infos.chatRemindCreated)?.send({ embeds: [embed], content: `${user}` }).catch(e=>{})
            }

            stopRemindTime(infos.userId, infos._id, client)
        }, infos.remindTime - Date.now())

        let reminds = getUserReminds(infos.userId)
        reminds.push({
            timeout: awaitTime,
            id: infos._id
        })

        remindsActives[infos.userId] = reminds
    }
}

async function stopRemindTime(userId, id, client){
    await client.dbUser.updateOne({ _id: userId, "reminds._id": id },{
        $set: {
            "reminds.$.ended": true
        }
    })

    const remind = getUserReminds(userId).find(remind=> remind.id == id)

    clearTimeout(remind.timeout)

    const reminds = getUserReminds(userId).filter(remind=> remind.id != id)
    remindsActives[userId] = reminds
}

function getUserReminds(id){
    !remindsActives[id] && (remindsActives[id] = [])
    return remindsActives[id]
}

async function readyUpReminds(client){
    const users = await client.dbUser.find({})

    users.forEach(user=>{
        const reminds = user.reminds.filter(remind => !remind.ended)
        if(!reminds.length) return;

        reminds.forEach(remind=>{
            startRemid({
                userId: user._id,
                remind: remind.remind,
                remindTime: remind.remindTime,
                chatRemindCreated: remind.chatRemindCreated,
                _id: remind._id
            }, client)
        })
    })
}