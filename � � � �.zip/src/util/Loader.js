const { readdirSync, statSync } = require('fs');

module.exports = class Loader {
    constructor(client) {
        this.client = client;
        this.commands = [];
        this.prefixCommands = [];
    }
    loadAll() {
        this.loadCommands();
        this.loadPrefixCommands();
        this.loadListeners();
    }
    loadPrefixCommands() {
        this.loadFolder('prefixCommands', (cmd) => {
            this.prefixCommands.push(cmd);
        })
    }
    loadCommands() {
        this.loadFolder('slashCommands', (cmd) => {
            this.commands.push(cmd);
        })
    }
    loadListeners() {
        this.loadFolder('eventListeners', (event) => {
            this.client[event.once ? 'once' : 'on'](event.eventName, event.exec.bind(null, this.client));
        })
    }
    loadFolder(folder, callback = () => { }) {
        const files = readdirSync(folder);
        for (const file of files) {
            const filePath = `../../${folder}/${file}`;
            if (file.endsWith("js")) {
                const fileReq = require(filePath);
                callback(fileReq, file, filePath);
            } else this.loadFolder(`${folder}/${file}`, callback);
        }
    }
}