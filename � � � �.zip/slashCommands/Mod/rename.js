const Discord = require("discord.js");

module.exports = {
  name: 'renomear', 
  description: 'a', 
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "canal",
      description: "Renomeia o canal atual",
      type: Discord.ApplicationCommandOptionType.Subcommand,
      options: [
        {
          name: 'nome', 
          description: 'O novo nome para o canal', 
          type: Discord.ApplicationCommandOptionType.String, 
          required: true, 
        }
      ],
    }
  ],

  exec: async ({client, interaction}) => {
   
    if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageChannels)) {
      return interaction.reply({ content: '☠️ Você não tem permissão para renomear canais, seu randolinha', ephemeral: true });
    }
    

    const newName = interaction.options.getString('nome');
    const channel = interaction.channel;
    
    
    try {
      await channel.edit({ name: newName });
      const successEmbed = new Discord.EmbedBuilder()
        .setColor(client.config.mainColor)
        .setTitle('☝️🤓 Canal Renomeado')
        .setDescription(`O nome do canal foi alterado com sucesso para: **${newName}**`)
        .setTimestamp();
      
     
      await interaction.reply({ embeds: [successEmbed], ephemeral: true });
    } catch (error) {
      console.error(error);
      interaction.reply({ content: '❌ || Ocorreu um erro ao tentar renomear o canal.', ephemeral: true });
    }
  }
}