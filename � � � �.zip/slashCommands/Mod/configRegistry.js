const Discord = require("discord.js");

module.exports = {
    name: 'configregistry',
    description: 'Configurar sistema de registro.',
    default_member_permissions: 0,
     exec: async ({ client, interaction }) => {
        const guildDb = async ()=> await client.dbGuild.findOne({ _id: interaction.guild.id }) || await client.dbGuild.create({ _id: interaction.guild.id })
         
        const registerEmbed = new Discord.EmbedBuilder()
			.setTitle('Registre-se aqui.')
            .setDescription(`> **Bem vindo a ${interaction.guild.name}, a baixo você poderá se registrar**`)
            .setColor(client.config.mainColor);

        const registerButton = new Discord.ActionRowBuilder()
        .addComponents(
            new Discord.ButtonBuilder()
            .setCustomId(`register`)
            .setLabel('Registrar')
            .setEmoji("<:PrefixIcon:1151931129469878484>")
            .setStyle(Discord.ButtonStyle.Primary),
        );

        const cancelButton = new Discord.ActionRowBuilder()
        .addComponents(
            new Discord.ButtonBuilder()
            .setCustomId(`cancel`)
            .setEmoji("<:X_:1151936937540726905>")
            .setLabel('Cancelar')
            .setStyle(Discord.ButtonStyle.Secondary),
        );

        const generateMessage = async() =>{
            const databaseOfGuild = await guildDb()
            const roleSet = interaction.guild.roles.cache.get(databaseOfGuild.register.role)

            const embedConfigRegistry = new Discord.EmbedBuilder()
            .setAuthor({ name: `Configurar registro em ${interaction.guild.name}`, iconURL: interaction.guild.iconURL()})
            .addFields(
                {
                    name: `> **Sistema ativo:**`,
                    value: databaseOfGuild.register.active && roleSet ? "`✅ Ativo`" : "`❌ Desativado`",
                    inline: true
                },
                {
                    name: `> **Cargo do registro:**`,
                    value: `${databaseOfGuild.register.role ? `${roleSet || "`Cargo deletado`"}` : "`Sem cargo`"}`,
                    inline: true
                },
            )
            .setColor(client.config.mainColor);
            
            const buttonsConfigRegistry = new Discord.ActionRowBuilder()
            .addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId("active/desactive")
                    .setLabel(databaseOfGuild.register.active && roleSet ? "Desativar" : "Ativar")
                    .setEmoji(databaseOfGuild.register.active && roleSet ? "<:OnBlue:1152616795350499458>" : "<:Off:1149308391324401674>")
                    .setDisabled(!roleSet)
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`setRole`)
                    .setEmoji("<:Member:1150639703658352760>")
                    .setLabel('Setar Cargo')
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`reset`)
                    .setLabel('Resetar Sistema')
                    .setEmoji("<:Reset:1149309446904877097>")
                    .setStyle(Discord.ButtonStyle.Danger),
            );

            return { embeds: [embedConfigRegistry], components: [buttonsConfigRegistry], fetchReply: true, ephemeral: true }
        }
            
        interaction.reply(await generateMessage()).then(msg=>{
            
            const collector = msg.createMessageComponentCollector({ idle: 1000 * 60 * 5 });

            collector.on('collect', async i => {
                if(i.isButton()){
                    const { customId: Button } = i

                    if(Button == "cancel"){
                        i.update(await generateMessage())
                    }
                    if(Button == "reset"){
                        await client.dbGuild.updateOne({ _id: i.guild.id },{
                            $set:{
                                register: {}
                            }
                        })
                        i.update(await generateMessage())
                    }
                    if(Button == "setRole"){
                        const rolesRow = new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.RoleSelectMenuBuilder()
                            .setCustomId(Button)
                            .setPlaceholder("Selecione um cargo para setar.")
                        )
                        i.update({ components: [rolesRow, cancelButton]})
                    }
                    if(Button == "active/desactive"){
                        const databaseOfGuild = await guildDb()
                        if(databaseOfGuild.register.active){
                            await client.dbGuild.updateOne({ _id: i.guild.id },{
                                $set:{
                                    "register.active": false
                                }
                            })
                            i.update(await generateMessage())
                        } else {
                            const channelsRow = new Discord.ActionRowBuilder()
                            .addComponents(
                                new Discord.ChannelSelectMenuBuilder()
                                .setCustomId(Button)
                                .setPlaceholder('Canal para enviar a mensagem de registro.')
                                .setChannelTypes([Discord.ChannelType.GuildText])
                            );
                            i.update({ components: [channelsRow, cancelButton]})
                        }
                        
                    }
                }
                if(i.isRoleSelectMenu()){
                    const role = i.guild.roles.cache.get(i.values[0])
                    if(!role || role.comparePositionTo(interaction.guild.members.me.roles.highest) >= 0 || role.tags?.botId){
                        return i.reply({ content: `O cargo selecionado não pode ser adicionado por ser de um bot ou estar acima do meu.`, ephemeral: true})
                    }
                    await client.dbGuild.updateOne({ _id: i.guild.id },{
                        $set:{
                            "register.role": role.id
                        }
                    })
                    i.update(await generateMessage())
                }
                if(i.isChannelSelectMenu()){
                    const channel = i.guild.channels.cache.get(i.values[0])
                    try {
                        await channel.send({ embeds: [registerEmbed], components: [registerButton] })
                        await client.dbGuild.updateOne({ _id: i.guild.id },{
                            $set:{
                                "register.active": true
                            }
                        })
                        await i.update(await generateMessage())
                        i.followUp({ content: `Mensagem de registro enviada para o canal ${channel} com sucesso!`, ephemeral: true })
                    } catch (error) {
                        return i.reply({ content: `Não foi possivel mandar a mensagem de registro neste canal.`, ephemeral: true})
                    }
                }
            });

        })
    }
}