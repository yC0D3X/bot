const { readyUpReminds } = require("../guildSystems/reminds")

module.exports = {
    once: true,
    eventName: "ready",
    exec: async (client) => {
        //Recarregar reminds
        readyUpReminds(client)

        //Carregar comandos
        try {
            client.guilds.cache.get(client.config.mainGuild)?.commands.set([])
            client.application?.commands.set(client.loader.commands)
            console.log('[COMMANDS] SlashCommands carregados com sucesso.');
        } catch (error) {
            console.error(error);
        }
    }
}