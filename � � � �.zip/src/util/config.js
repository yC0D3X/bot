const { EmbedBuilder } = require("discord.js");
const mainColor = "2ecc74"

module.exports = {
    prefix: ".",
    ownerId: "679711303849345025",
    clientID: "1141947690335342683",
    mainGuild: "",
    mainColor,
    enter: "",
    out: "",
    messageDelete: "",
    messageUpdate: "",
    removedCallLog: "",
    Ticket: {
        blackListRole: "1142431073360433213",
        categoriaTicketsCloseds: "1161115083175379075",
        channelLog: "1161108298276286464",
        categoriaDefault: "1161084715936272414",
        menus: [
            {
                embed: new EmbedBuilder()
                .setDescription('Olá, se você está lendo isso aqui, provavelmente esteja precisando de ajuda. Selecione uma categoria abaixo de acordo com sua necessidade. \n\n > Hórario de atendimento: **08:00** às **22:00** - Segunda a Domingo, horario de Brasília ( exeto feriados ). \n > \n > Podemos atender fora do horário estipulado mas não é garantido. \n\n*Utilize a categoria correta, caso o contrário seu ticket será fechado.*')
                .setThumbnail('https://cdn.discordapp.com/attachments/1142094012614967358/1142429367385997373/company.png')
                .setColor(mainColor),
                identificador: "Ticket para todos",
                suportRoles: ["1141953034960781332"],
                mensagemInicial: "Selecione uma categoria de ticket",
                opções: [
                    {
                        nome: "Cofres - Central Street",
                        nameChannelEmoji: "🔐",
                        emoji: "<:hdev_cofre:1161120097872658533>",
                        description: "Use caso deseje alugar na Central Street.",
                        categoria: "1141952145269194812"
                    },
                    {
                        nome: "Cofres - QG Russia",
                        nameChannelEmoji: "🔐",
                        emoji: "<:hdev_cofre:1161120097872658533>",
                        description: "Use caso deseje alugar no QG Russia.",
                        categoria: "1198501122130849942"
                    },
                    {
                        nome: "Dúvidas",
                        nameChannelEmoji: "❓",
                        emoji: "<:hdev_dvidas:1161120520557830204>",
                        description: "Deseja tirar alguma duvida?",
                        categoria: "1141952174780321832"
                    }
                ]
            },
            {
                embed: new EmbedBuilder()
                .setDescription('Olá, se você está lendo isso aqui, provavelmente esteja precisando de ajuda. Selecione uma categoria abaixo de acordo com sua necessidade. \n\n > Hórario de atendimento: **08:00** às **22:00** - Segunda a Domingo, horario de Brasília ( exeto feriados ). \n > \n > Podemos atender fora do horário estipulado mas não é garantido. \n\n*Utilize a categoria correta, caso o contrário seu ticket será fechado.*')
                .setThumbnail('https://cdn.discordapp.com/attachments/1142094012614967358/1142429367385997373/company.png')
                .setColor(mainColor),
                identificador: "TIcket para clientes",
                suportRoles: ["1141953034960781332"],
                mensagemInicial: "Selecione uma categoria de ticket",
                opções: [
                    {
                        nome: "Mods",
                        nameChannelEmoji: "📁",
                        emoji: "📁",
                        description: "Envio de mods e outros.",
                        categoria: ""
                    }
                ]
            },
            {
                embed: new EmbedBuilder()
                .setDescription('Olá, se você está lendo isso aqui, provavelmente esteja precisando de ajuda. Selecione uma categoria abaixo de acordo com sua necessidade. \n\n > Hórario de atendimento: **08:00** às **22:00** - Segunda a Domingo, horario de Brasília ( exeto feriados ). \n > \n > Podemos atender fora do horário estipulado mas não é garantido. \n\n*Utilize a categoria correta, caso o contrário seu ticket será fechado.*')
                .setThumbnail('https://cdn.discordapp.com/attachments/1142094012614967358/1142429367385997373/company.png')
                .setColor(mainColor),
                identificador: "TIcket para monstros",
                suportRoles: ["1141953034960781332"],
                mensagemInicial: "Selecione uma categoria de ticket",
                opções: [
                    {
                        nome: "Mods",
                        nameChannelEmoji: "📁",
                        emoji: "📁",
                        description: "Envio de mods e outros.",
                        categoria: "1026161714753970196"
                    }
                ]
            }
        ]
    }
}