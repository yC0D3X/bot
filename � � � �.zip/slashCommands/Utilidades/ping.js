const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: 'ping',
    description: 'Comando para ver seu ping',
    exec: ({ client, interaction }) => {
        const embed = new EmbedBuilder()
            .setDescription(`${interaction.user}, Pong! **${client.ws.ping}ms**.`)
            .setColor(client.config.mainColor);
            
        interaction.reply({ embeds: [embed] });
    }
}