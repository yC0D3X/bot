const Discord = require('discord.js');

module.exports = {
    name: 'statusbot',
    description: 'Setar a atividade do bot',
    default_member_permissions: [Discord.PermissionFlagsBits.Administrator],
    options: [
        {
            name: 'tipo',
            description: 'Escolha o tipo',
            type: Discord.ApplicationCommandOptionType.String,
            required: true,
            choices: [
                { name: `Remover`, value: `0` },
                { name: `Jogando`, value: `Playing` },
                { name: `Transmissão`, value: `Streaming` },
                { name: `Ouvindo`, value: `Listening` },
                { name: `Assistindo`, value: `Watching` },
                { name: `Competindo`, value: `Competing` }
            ]
        },
        {
            name: 'atividade',
            description: 'Nova atividade: Maximo de 128 carácteres.',
            type: Discord.ApplicationCommandOptionType.String,
            minLength: 3,
            maxLength: 128,
            required: true
        }
    ],
    
    exec: async ({ client, interaction }) => {
        if(![client.config.ownerId].includes(interaction.user.id)) return interaction.reply({ content: "Somente o Adm pode usar este comando", ephemeral: true })
        const activityType = interaction.options.getString('tipo');
        const activityName = interaction.options.getString('atividade');
        
        const embed = new Discord.EmbedBuilder()
            .setColor(client.config.mainColor)
            .setTitle('Atividade setada com sucesso!')
            .setDescription(`> **Minha nova atividade foi setada com sucesso para: \`${activityName}\`**`)

        client.user.setPresence({
            activities: [{
                type: Discord.ActivityType[activityType],
                url: 'https://www.twitch.tv/higaozx',
                name: activityName
            }]
        });
        
        interaction.reply({ embeds: [embed], ephemeral: true });
    }
};