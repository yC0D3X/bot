const Discord = require("discord.js");

module.exports = {
    name: 'configlogs',
    description: 'Configurar sistemas do bot.',
    default_member_permissions: 0,
     exec: async ({ client, interaction }) => {
        const guildDb = async ()=> await client.dbGuild.findOne({ _id: interaction.guild.id }) || await client.dbGuild.create({ _id: interaction.guild.id })

        const cancelButton = new Discord.ActionRowBuilder()
        .addComponents(
            new Discord.ButtonBuilder()
            .setCustomId(`cancel`)
            .setEmoji("<:X_:1151936937540726905>")
            .setLabel('Cancelar')
            .setStyle(Discord.ButtonStyle.Secondary),
        );

        const generateMessage = async() =>{
            const databaseOfGuild = await guildDb()
            function getChannel(param){
                return interaction.guild.channels.cache.get(databaseOfGuild[param].channel)
            }
            const embedConfig = new Discord.EmbedBuilder()
            .setAuthor({ name: `Configurar bot em ${interaction.guild.name}`, iconURL: interaction.guild.iconURL()})
            .addFields(
                {
                    name: `> **Log's de Entrada:** `,
                    value: databaseOfGuild.enterLogs.active && getChannel("enterLogs") ? `${getChannel("enterLogs")}` : "`❌ Desativado`",
                    inline: true
                },
                {
                    name: `> **Log's de Saída:** `,
                    value: databaseOfGuild.outLogs.active && getChannel("outLogs") ? `${getChannel("outLogs")}` : "`❌ Desativado`",
                    inline: true
                },
                {
                    name: `> **Log's de mensagens:** `,
                    value: databaseOfGuild.messagesLogs.active && getChannel("messagesLogs") ? `${getChannel("messagesLogs")}` : "`❌ Desativado`",
                    inline: true
                },
                {
                    name: `> **Log's de removido da call:** `,
                    value: databaseOfGuild.removedCallLog.active && getChannel("removedCallLog") ? `${getChannel("removedCallLog")}` : "`❌ Desativado`",
                    inline: true
                },
            )
            .setColor(client.config.mainColor);
            
            const buttonsConfigEnter = new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`e`)
                    .setLabel('Logs de Entrada:')
                    .setDisabled(true)
                    .setStyle(Discord.ButtonStyle.Danger),
                    new Discord.ButtonBuilder()
                    .setCustomId("active.desactive/enterLogs")
                    .setLabel(databaseOfGuild.enterLogs.active && getChannel("enterLogs") ? "Desativar" : "Ativar")
                    .setEmoji(databaseOfGuild.enterLogs.active && getChannel("enterLogs") ? "<:OnBlue:1152616795350499458>" : "<:Off:1149308391324401674>")
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`setChannel/enterLogs`)
                    .setEmoji("<:Hash:1149342519855947886>")
                    .setLabel('Setar Canal')
                    .setDisabled(!databaseOfGuild.enterLogs.active)
                    .setStyle(Discord.ButtonStyle.Secondary),
            );
            const buttonsConfigOut = new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`a`)
                    .setLabel('Logs de Saida:')
                    .setDisabled(true)
                    .setStyle(Discord.ButtonStyle.Danger),
                    new Discord.ButtonBuilder()
                    .setCustomId("active.desactive/outLogs")
                    .setLabel(databaseOfGuild.outLogs.active && getChannel("outLogs") ? "Desativar" : "Ativar")
                    .setEmoji(databaseOfGuild.outLogs.active && getChannel("outLogs") ? "<:OnBlue:1152616795350499458>" : "<:Off:1149308391324401674>")
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`setChannel/outLogs`)
                    .setEmoji("<:Hash:1149342519855947886>")
                    .setLabel('Setar Canal')
                    .setDisabled(!databaseOfGuild.outLogs.active)
                    .setStyle(Discord.ButtonStyle.Secondary),
            );
            const buttonsConfigMessages = new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`aa`)
                    .setLabel('Logs de mensagens:')
                    .setDisabled(true)
                    .setStyle(Discord.ButtonStyle.Danger),
                    new Discord.ButtonBuilder()
                    .setCustomId("active.desactive/messagesLogs")
                    .setLabel(databaseOfGuild.messagesLogs.active && getChannel("messagesLogs") ? "Desativar" : "Ativar")
                    .setEmoji(databaseOfGuild.messagesLogs.active && getChannel("messagesLogs") ? "<:OnBlue:1152616795350499458>" : "<:Off:1149308391324401674>")
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`setChannel/messagesLogs`)
                    .setEmoji("<:Hash:1149342519855947886>")
                    .setLabel('Setar Canal')
                    .setDisabled(!databaseOfGuild.messagesLogs.active)
                    .setStyle(Discord.ButtonStyle.Secondary),
            );
            const buttonsConfigCall = new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId(`aaa`)
                    .setLabel('Logs de call:')
                    .setDisabled(true)
                    .setStyle(Discord.ButtonStyle.Danger),
                    new Discord.ButtonBuilder()
                    .setCustomId("active.desactive/removedCallLog")
                    .setLabel(databaseOfGuild.removedCallLog.active && getChannel("removedCallLog") ? "Desativar" : "Ativar")
                    .setEmoji(databaseOfGuild.removedCallLog.active && getChannel("removedCallLog") ? "<:OnBlue:1152616795350499458>" : "<:Off:1149308391324401674>")
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`setChannel/removedCallLog`)
                    .setEmoji("<:Hash:1149342519855947886>")
                    .setLabel('Setar Canal')
                    .setDisabled(!databaseOfGuild.removedCallLog.active)
                    .setStyle(Discord.ButtonStyle.Secondary),
            );

            return { embeds: [embedConfig], components: [buttonsConfigEnter, buttonsConfigOut, buttonsConfigMessages, buttonsConfigCall], fetchReply: true, ephemeral: true }
        }
            
        interaction.reply(await generateMessage()).then(msg=>{
            
            const collector = msg.createMessageComponentCollector({ idle: 1000 * 60 * 5 });

            collector.on('collect', async i => {
                if(i.isButton()){

                    function createMenuChannel(){
                        const channelsRow = new Discord.ActionRowBuilder()
                            .addComponents(
                                new Discord.ChannelSelectMenuBuilder()
                                .setCustomId(Button)
                                .setPlaceholder('Canal que será enviado as mensagens')
                                .setChannelTypes([Discord.ChannelType.GuildText])
                            );
                            i.update({ components: [channelsRow, cancelButton]})
                    }

                    const { customId: Button } = i

                    if(Button == "cancel"){
                        i.update(await generateMessage())
                    }
                    
                    if(Button.startsWith("setChannel/")){
                        createMenuChannel()
                    }

                    if(Button.startsWith("active.desactive/")){
                        const [, database] = Button.split("/")

                        const setDatabase = {}

                        setDatabase[database] = {
                            active: false
                        }

                        const databaseOfGuild = await guildDb()
                        if(databaseOfGuild[database].active){
                            await client.dbGuild.updateOne({ _id: i.guild.id },{
                                $set: setDatabase
                            })
                            i.update(await generateMessage())
                        } else {
                            createMenuChannel()
                        }
                        
                    }
                }
                
                if(i.isChannelSelectMenu()){
                    const [, database] = i.customId.split("/")
                    const channel = i.guild.channels.cache.get(i.values[0])

                    const setDatabase = {}

                        setDatabase[database] = {
                            active: true,
                            channel: channel.id
                        }
                    
                    await client.dbGuild.updateOne({ _id: i.guild.id },{
                        $set: setDatabase
                    })
                    await i.update(await generateMessage())
                }
            });

        })
    }
}