const { EmbedBuilder } = require("discord.js")

module.exports = {
    once: false,
    eventName: "guildMemberAdd",
    exec: async (client, member) => {
        
        const serverDB = await client.dbGuild.findOne({ _id: member.guild.id })
        if(!serverDB || !serverDB.enterLogs.active) return;

        const channelLogs = client.channels.cache.get(serverDB.enterLogs.channel)

        channelLogs?.send({
         embeds: [
             new EmbedBuilder()
             .setTitle(`<:hdev_user:1151584770107645995> Novo membro no servidor:`)
             .setColor(client.config.mainColor)
             .setDescription(`> Membro: 
            \`\`\`${member.user.username}\`\`\`
            > **Conta criada:**
            <t:${~~(member.user.createdTimestamp / 1000)}:R>
            `)
			 .setFooter({ text: `ID: (${member.user.id})`})
			 .setThumbnail(member.displayAvatarURL())
             .setTimestamp()
         ]
        })
    }
}