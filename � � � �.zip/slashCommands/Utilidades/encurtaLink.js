const Discord = require('discord.js')

module.exports = {
    name: "encurtar",
    description: "[✨] Encurtador de URLs",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "url",
            description: "[🛠] encurtar url",
            type: Discord.ApplicationCommandOptionType.Subcommand,
            options: [
				{
				name: 'link', 
				description: '[~] link da url a ser encurtada', 
				type: Discord.ApplicationCommandOptionType.String, 
				required: true, 
				}
			],
        }
    ],

    exec: async({interaction, client}) => {
        
        const { options } = interaction
        let url = options.getString('link')
        
        let apis = [ // Pegue sua api key no site da rebrand.ly - Pode pegar + de 1 api
            'a709423a70e9411285c5ef0e96967517'
        ]
    
        let apisRandom = apis[Math.floor(Math.random() * apis.length)]
    
        let headers = {
            "Content-Type": "application/json",
            "apikey": `${apisRandom}`,
        }
     
        let linkRequest = {
            destination: url,
            domain: { fullName: "rebrand.ly" }
          }
     
        fetch("https://api.rebrandly.com/v1/links", {
            method: "POST",
            headers: headers,
            body: JSON.stringify(linkRequest)
        }).then(response => response.json()).then(json => { 
    
            if(json.shortUrl === undefined) {
                interaction.reply({ content: ":x: Esta URL não é valida, tente novamente!" })
            } else {
    
            let embed = new Discord.EmbedBuilder()
            .setAuthor({ name: "URL encurtada!", iconURL: interaction.user.avatarURL() })
            .setColor(client.config.mainColor)
            .setDescription(`
            :white_check_mark: \`>\` Sua URL foi encurtada com sucesso, clique [aqui](https://${json.shortUrl}) para ir até o link ou clique no botão abaixo!
            `)
            .addFields(
                { name: "🔗 URL:", value: 'https://' + json.shortUrl, inline: true},
                { name: "🔗 URL Encurtada:", value: url, inline: true}
            )

            let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                .setURL(`https://${json.shortUrl}`)
                .setLabel('Ir até a URL')
                .setEmoji("🔗")
                .setStyle(Discord.ButtonStyle.Link)
            )

            interaction.reply({
                embeds: [embed],
                components: [row]
            })
        }
         });
    }
}