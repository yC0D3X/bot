const { EmbedBuilder, PermissionFlagsBits, ApplicationCommandOptionType } = require("discord.js");

module.exports = {
    name: 'lockdown',
    description: 'Fechar o canal ou servidor',
    default_member_permissions: [PermissionFlagsBits.ManageGuild],
    options: [
        {
            name: "alvo",
            description: "Selecione o que deseja lockar",
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: "Servidor",
                    value: "server"
                },
                {
                    name: "Canal",
                    value: "channel"
                }
            ]
        }
    ],
    exec: async ({ client, interaction }) => {
        const target = interaction.options.getString("alvo")

        if(target == "server"){
            const role = interaction.guild.roles.everyone
            const permissions = role.permissions.toArray()
            if(role.permissions.has(PermissionFlagsBits.SendMessages)){
                const perms = permissions.filter(perm => perm != "SendMessages")
                await role.edit({ permissions: perms })
                interaction.reply({ embeds: [
                    new EmbedBuilder()
                    .setAuthor({ name: `🔒 Lockdown...`, iconURL: interaction.guild.iconURL()})
                    .setColor(client.config.mainColor)
                    .setDescription(`> **Servidor fechado com sucesso!**`)
                    .setTimestamp()
                ] , ephemeral: true })
            } else {
                interaction.reply({ embeds: [
                    new EmbedBuilder()
                    .setAuthor({ name: `🔒 Lockdown...`, iconURL: interaction.guild.iconURL()})
                    .setColor(client.config.mainColor)
                    .setDescription(`> **O servidor ja está fechado**`)
                    .setTimestamp()
                ] , ephemeral: true })
            }
        } else {
            const role = interaction.channel.permissionsFor(interaction.guild.roles.everyone)
            if(role.has(PermissionFlagsBits.SendMessages)){
                interaction.channel.permissionOverwrites.create(interaction.channel.guild.roles.everyone, { SendMessages: false });
                interaction.reply({ embeds: [
                    new EmbedBuilder()
                    .setAuthor({ name: `🔒 Lockdown!`, iconURL: interaction.guild.iconURL()})
                    .setColor(client.config.mainColor)
                    .setDescription(`> **Canal fechado com sucesso!**`)
                    .setTimestamp()
                ] , ephemeral: true })
            } else {
                interaction.reply({ embeds: [
                    new EmbedBuilder()
                    .setAuthor({ name: `🔒 Lockdown...`, iconURL: interaction.guild.iconURL()})
                    .setColor(client.config.mainColor)
                    .setDescription(`> **O Canal ja está fechado**`)
                    .setTimestamp()
                ] , ephemeral: true })
            }
        }
    }
}