const { PermissionFlagsBits, ApplicationCommandOptionType, EmbedBuilder } = require("discord.js");

module.exports = {
    name: 'pause',
    description: 'Dar pause e resume nas músicas',
    exec: async ({client, interaction}) => {
        const serverDB = await client.dbGuild.findOne({ _id: interaction.guild.id })

        if(!serverDB.music.admPermToUse){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, não sou autorizado a poder usar meus comandos de musica neste servidor.`, iconURL: client.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        if(interaction.member.voice.channel?.id != interaction.guild.members.me.voice.channel?.id){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, você deve estar na mesma call que eu para usar o comando.`, iconURL: client.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        if(serverDB 
            && serverDB.music.dj.active 
            && !interaction.member.roles.cache.has(serverDB.music.dj.role)
            && !interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, você não tem cargo de dj para pausar músicas.`, iconURL: interaction.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        const player = client.vulkava.players.get(interaction.guild.id);

        if(!player){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, eu não estou mais tocando música.`, iconURL: client.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        player?.pause(!player.paused)
        interaction.reply({ embeds: [
            new EmbedBuilder()
            .setAuthor({ name: `${!player.paused ? `Música tocando novamente.` : `Música pausada.`}`, iconURL: interaction.guild.iconURL() })
            .setColor(client.config.mainColor)
          ]});
    }
}