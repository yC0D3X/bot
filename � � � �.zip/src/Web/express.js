const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const { EmbedBuilder } = require('discord.js');
const app = express();
const port = 8080;

module.exports = async(client)=>{

app.use(express.static(__dirname + '/assets'))
app.use(bodyParser.json())
app.use(session({
  secret: 'hu2bhr28rb3n28klnA0k',
  resave: false,
  saveUninitialized: true,
}));

app.get('/login', (req, res) => {
  res.sendFile(__dirname + '/APP/Home/login.html');
});

app.post('/login', async(req, res) => {
  const user = await client.users.fetch(client.config.ownerId).catch(e=>{})
  const ip = req.headers['x-forwarded-for']; 
  
  if(req.body.senha !== client.webServerPassword || req.body.senha == "" ){
    res.send({ message: "Senha incorreta, por favor, tente gerar uma nova." })
    const embed = new EmbedBuilder()
            .setTitle(`❗| Tentativa de login efetuada!`) 
            .setThumbnail(client.user.avatarURL())
            .setColor(client.config.mainColor)
            .setDescription(`> Alguém acaba de tentar acessar meu sistema, se não foi você, re-gere minha senha por segurança.\nEndereço IP: ${ip}`)
            .setTimestamp()
    user.send({
      embeds: [embed]
    }).catch(e=>{
      console.log("Erro: Não foi possivel enviar mensagem de tentativa de login efetuado. Por: " + e)
    })
  } else {
    req.session.passwordPassed = req.body.senha
    res.send({ message: "ok" })
    const embed = new EmbedBuilder()
            .setTitle(`❗| Login efetuado em meu sistema!`) 
            .setThumbnail(client.user.avatarURL())
            .setColor(client.config.mainColor)
            .setDescription(`> Novo login efetuado. Caso não foi você, re-gere minha senha urgentemente.\nEndereço IP: ${ip}`)
            .setTimestamp()
    user.send({
      embeds: [embed]
    }).catch(e=>{
      console.log("Erro: Não foi possivel enviar mensagem de login efetuado. Por: " + e)
    })
  }
});

app.get('/botimage', (req, res) => {
  res.json({
    image: client.user.avatarURL({ extension: "png", size: 1024 })
  });
});

app.get('/guilds', (req, res) => {
  const guilds = client.guilds.cache.map(guild => {
    return {
      id: guild.id,
      name: guild.name,
      iconUrl: guild.iconURL()
    };
  });
  res.json(guilds);
});

app.get('/channels/:guildId', (req, res) => {

  const guildId = req.params.guildId;

  const guild = client.guilds.cache.get(guildId);
  if (!guild) {
    return res.status(404).json({ error: 'Servidor não encontrado' });
  }
  const channelNames = guild.channels.cache.filter(channel => channel.type === 0).map(channel => ({
    id: channel.id,
    name: channel.name
  }));
  res.json(channelNames);
});
app.get('/send/:channelId/:messageContent', async (req, res) => {
  const channeld = req.params.channelId;
  const messageContent = req.params.messageContent;

  const channel = client.channels.cache.get(channeld);
  if(channel){
    channel.send(messageContent).then(msg => {
      res.json({user: {username: msg.author.username, avatar: msg.author.avatar, id: msg.author.id}, content: msg.content, data: msg.createdTimestamp})
    })
  }
})
app.get('/messages/:channelId', async (req, res) => {

  try {
    const channelId = req.params.channelId;

    const channel = client.channels.cache.get(channelId);
    if (!channel) {
      return res.status(404).json({ error: 'Servidor não encontrado' });
    }


    const messages = await channel.messages.fetch({ limit: 100 })
    let mensagem = []
    messages.forEach(message => {
      if(message){
          mensagem.push({user: {username: message.author.username, avatar: message.author.avatar, id: message.author.id}, content: message.content, data: message.createdTimestamp, image: message.attachments, embeds: message.embeds })
      }else{
        mensagem.push[{user: {username: client.user.username, avatar: client.user.avatar, id: client.user.id}, content: `Nenhuma mensagem encontrada`, data: null}]
      }
      
    });
    res.json(mensagem);
  } catch (error) {
    mensagem = [{user: {username: client.user.username, avatar: client.user.avatar, id: client.user.id}, content: `Erro 404`}]
    res.json(mensagem);
  }
});

app.use((req, res, next)=>{
  req.session.passwordPassed !== client.webServerPassword ? res.redirect("/login") : next()
})

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/APP/Home/index.html');
});

app.listen(port, () => {
  console.log(`[WEBSERVER] Servidor web rodando.`);
});

}