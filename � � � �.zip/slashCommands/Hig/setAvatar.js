const Discord = require("discord.js");
const axios = require('axios');
module.exports = {
  name: "setavatar",
  description: "Setar Avatar do Bot.",
  options: [
    {
        name: "arquivo",
        description: "Imagem para colocar no perfil do Bot",
        type: Discord.ApplicationCommandOptionType.Attachment,
        required: false
    }
  ],
  exec: async ({client, interaction}) => {
    if(![client.config.ownerId].includes(interaction.user.id)) return interaction.reply({ content: "Somente o Adm pode usar este comando", ephemeral: true })
    await interaction.deferReply({ ephemeral: true })
    const attachment = interaction.options.getAttachment("arquivo")

    if(!attachment){
        const msgReply = await interaction.followUp({ content: "> **Envie o arquivo.**", fetchReply: true })
        const collector = interaction.channel.createMessageCollector({ filter: m=> m.author.id == interaction.user.id, idle: 15_000 });

        collector.on('collect', m => {
            const attachment = [...m.attachments.values()][0]
            setTimeout(()=>m.delete().catch(e=>{}), 1500)
            if(attachment){
                collector.stop()
                verify(attachment)
            } else {
                interaction.followUp({ content: "> **Não envie mensagens, envie apenas arquivos `.txt`.**", ephemeral: true })
            }
        });
        collector.on('end', (c, m) => {
            if(m == "idle") interaction.editReply({ content: "> Arquivo não enviado a tempo, use o comando novamente."})
        });
    } else {
        verify(attachment)
    }

    function verify(attachment){
        if(!attachment.contentType.includes("image")) return interaction.followUp({ content: "> **Perdão, mas eu não consigo ler este formato de arquivo.**", ephemeral: true })
        client.user.setAvatar(attachment.url)
        interaction.editReply({ content: "> **Imagem setada no bot com sucesso.**"})
    }
  }
}
