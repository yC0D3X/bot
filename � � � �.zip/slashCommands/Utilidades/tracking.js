const Discord = require("discord.js");
const { getInfoPackage } = require("trackorder-correios")

module.exports = {
  name: "rastrear",
  description: ".",
  options: [
    {
        name: "encomenda",
        description: "Rastrear encomendas dos correios",
        type: Discord.ApplicationCommandOptionType.Subcommand,
        options: [
            {
                name: "codigo",
                description: "Código de rastreio da encomenda.",
                type: Discord.ApplicationCommandOptionType.String,
                required: true
            }
        ]
    }
  ],
  exec: async ({client, interaction}) => {
    const orderCode = interaction.options.getString("codigo")

    getInfoPackage(orderCode).then(data=>{
        if(data.error){
            const embed = new Discord.EmbedBuilder()
            .setAuthor({ name: `Código de encomenda não encontrado nos sistemas dos correios.`, iconURL: client.user.avatarURL()})
            .setColor(client.config.mainColor)
            .setFooter({ text: `${client.user.username} | Todos Direitos Reservados`})
            .setTimestamp()

            return interaction.reply({ embeds: [embed], ephemeral: true })
        }

        const embed = new Discord.EmbedBuilder()
            .setThumbnail(client.user.avatarURL())
            .setColor(client.config.mainColor)
            .addFields(
                {
                    name: "📦 **Entregue:**",
                    value: `${data.delivered ? "Sim" : "Não"}`,
                    inline: true
                },
                {
                    name: "🚚 **Em transito:**",
                    value: `${data.inTransit ? "Sim" : "Não"}`,
                    inline: true
                },
                {
                    name: "🛫 **Objeto postado:**",
                    value: `<t:${~~(data.postedDate.getTime() / 1000)}:f>`,
                    inline: true
                }
            )
            .setDescription(`${data.updates.map(update=>{
                return `> **${update.status}** - ${update.localeCity ? `\`${update.localeCity}\`` : ""} ${update.transitInfos ? `==> \`${update.transitInfos.destination.split(" - ")[1]}\`` : ``} \n> (<t:${~~(update.date.getTime() / 1000)}:f>)`
            }).join("\n\n")
            }`)
            .setTitle("📦 Rastreamento de encomendas:")
            .setFooter({ text: `${client.user.username} | Todos Direitos Reservados`})
            .setTimestamp()

            interaction.reply({ embeds: [embed]})
    })
  }
}