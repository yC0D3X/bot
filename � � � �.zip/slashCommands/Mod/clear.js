const { PermissionFlagsBits, ApplicationCommandOptionType, EmbedBuilder } = require("discord.js");

module.exports = {
    name: 'limpar',
    description: 'Apagar mensagens do chat',
    default_member_permissions: [PermissionFlagsBits.ManageMessages],
    options: [
        {
            name: "quantidade",
            description: "Informe a quantidade de mensagens.",
            type: ApplicationCommandOptionType.Number,
            min_value: 1,
            max_value: 100,  
            required: true
        }
    ],
    exec: async ({client, interaction}) => {
        const amount = interaction.options.getNumber("quantidade")
        
        interaction.channel.bulkDelete(~~(amount), true).then(messages=>{
            interaction.reply({ embeds: [
                new EmbedBuilder()
                    .setAuthor({ name: `🧹 Clear`, iconURL: interaction.guild.iconURL()})
                    .setColor(client.config.mainColor)
                    .setDescription(`> Foram deletadas **${messages.size}** mensagens com sucesso.`)
                    .setTimestamp()
            ], ephemeral: true})
        })
    }
}   