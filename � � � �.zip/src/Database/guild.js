const { Schema, model } = require("mongoose");

const guildSet = new Schema({
    _id: { type: String },
    register: {
        active: { type: Boolean, default: false },
        role: { type: String },
    },
    enterLogs: {
        active: { type: Boolean, default: false },
        channel: { type: String },
    },
    outLogs: {
        active: { type: Boolean, default: false },
        channel: { type: String },
    },
    messagesLogs: {
        active: { type: Boolean, default: false },
        channel: { type: String },
    },
    removedCallLog: {
        active: { type: Boolean, default: false },
        channel: { type: String },
    },
    music: {
        admPermToUse: { type: Boolean, default: false },
        dj: {
            active: { type: Boolean, default: false },
            role: { type: String },
        }
    },
    gifzadaSystem: {
        admPermToUse: { type: Boolean, default: false },
        active: { type: Boolean, default: false },
        cooldown: { type: Number, default: 15000 },
        partials: {
            animate: {
                active: { type: Boolean, default: false },
                channel: { type: String },
            },
            banner: {
                active: { type: Boolean, default: false },
                channel: { type: String },
            },
            static: {
                active: { type: Boolean, default: false },
                channel: { type: String },
            },
        }
    }

});

  module.exports = model("Servidores", guildSet);