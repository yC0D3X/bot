const Discord = require("discord.js");
const { generateMenuRow } = require("../../eventListeners/guildSystems/tickets");

module.exports = {
  name: "menuticket",
  description: "Enviar no ticket o menu adm",
  dm_permission: false,
  default_member_permissions: 0,
    exec: async ({client, interaction}) => {
    if(!await client.users.fetch(interaction.channel.topic).catch(e=>{})) return interaction.reply({ content: "Você só pode usar este comando em canais que forem ticket's.", ephemeral: true})
  
    interaction.reply({ embeds: [new Discord.EmbedBuilder()
        .setTitle(`Sistema De Ticket - ${client.user.username}`)
        .setThumbnail(interaction.guild.iconURL())
        .setColor(client.config.mainColor)
        .setDescription(`> Aqui está o menu do ticket:`)
      ], components: [generateMenuRow()],ephemeral: true})
 }
};
