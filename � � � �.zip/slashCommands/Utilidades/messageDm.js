const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = {
    name: 'dm',
    description: 'Configurar mensagens na dm',
    exec: async ({ client, interaction }) => {

        const message = async () => {
            const userDb = await client.dbUser.findById(interaction.user.id) || await client.dbUser.create({ _id: interaction.user.id })
            
            const allSuporteRoles = [...new Set(client.config.Ticket.menus.map(menu=> menu.suportRoles).flat())]
            const hasRoleSuport = allSuporteRoles.find(role=> interaction.member.roles.cache.has(role))
            
            const fields = [
                {
                    name: `*__Lembretes na dm__*`,
                    value: `${userDb.dmMessages.remind ? `✅` : `❌`}`
                }
            ]
            hasRoleSuport && fields.push(
                {
                    name: `*Notificação de ticket na dm__*`,
                    value: `${userDb.dmMessages.ticket ? `✅` : `❌`}`
                }
            )

            const embed = new EmbedBuilder()
            .setAuthor({ name: `Configuração da DM de: ${interaction.user.username}.`, iconURL: interaction.user.avatarURL() })
            .setDescription("(Dm Ativa ✅, DM Desativada ❌)")
            .addFields(fields)
            .setColor(client.config.mainColor);
            
            const row = new ActionRowBuilder()
			.addComponents(
                new ButtonBuilder()
			.setCustomId('remindDm')
			.setLabel(`${userDb.dmMessages.remind ? `Desativar` : `Ativar`} DM para lembretes`)
			.setStyle(userDb.dmMessages.remind ? ButtonStyle.Danger : ButtonStyle.Success)
            )
            hasRoleSuport && row.addComponents(
                new ButtonBuilder()
			.setCustomId('ticketDm')
			.setLabel(`${userDb.dmMessages.ticket ? `Desativar` : `Ativar`} DM para tickets`)
			.setStyle(userDb.dmMessages.ticket ? ButtonStyle.Danger : ButtonStyle.Success)
            )

            return { embeds: [embed], components: [row] }
        }
            
        interaction.reply({ fetchReply: true, ephemeral: true, ...(await message()) }).then(msg=>{
            const collector = msg.createMessageComponentCollector({ idle: 1000 * 60 * 3 });

            collector.on('collect', async i => {
                const { customId: Button } = i
                const userDb = await client.dbUser.findById(interaction.user.id)

                if(Button == "remindDm"){
                    if(userDb.dmMessages.remind){
                        userDb.dmMessages.remind = false; await userDb.save();
                    } else {
                        userDb.dmMessages.remind = true; await userDb.save();
                    }
                    i.update(await message())
                }
                if(Button == "ticketDm"){
                    if(userDb.dmMessages.ticket){
                        userDb.dmMessages.ticket = false; await userDb.save();
                    } else {
                        userDb.dmMessages.ticket = true; await userDb.save();
                    }
                    i.update(await message())
                }

             })
        })
    }
}