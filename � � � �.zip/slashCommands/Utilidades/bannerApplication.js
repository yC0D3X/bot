const Discord = require("discord.js");

module.exports = {
  name: "Ver Banner",
  type: Discord.ApplicationCommandType.User,
  dm_permission: false,
  exec: async ({client, interaction}) => {
    const user = interaction.targetUser
    const getBanner = await client.users.fetch(user.id, {force: true})
    
    if(!user?.banner){
        return interaction.reply({ content: `**${user.username}** não tem banner.`, ephemeral: true})
    }

    const embed = new Discord.EmbedBuilder()
    .setColor(client.config.mainColor)
    .setTitle(`> Banner de ${user.username}`)
    .setImage(user.bannerURL({ size: 1024, extension: "png"}))
    .setFooter({ text: `${client.user.username} | Todos Direitos Reservados`})

	let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                .setURL(user.bannerURL({ size: 1024, extension: "png"}))
                .setLabel('Baixar imagem')
                .setEmoji("<:hdev_download:1181491713345343508>")
                .setStyle(Discord.ButtonStyle.Link)
    )
  
    interaction.reply({ embeds: [embed] , components: [row], phemeral: true })
  }
}