require('dotenv').config();

const { GatewayIntentBits, MessageEmbed } = require('discord.js');
const Client = require('./src/Bot/DiscordBot');

console.log(`
██████╗ ██╗   ██╗    ██╗  ██╗██╗ ██████╗  █████╗  ██████╗ 
██╔══██╗╚██╗ ██╔╝    ██║  ██║██║██╔════╝ ██╔══██╗██╔═══██╗
██████╔╝ ╚████╔╝     ███████║██║██║  ███╗███████║██║   ██║
██╔══██╗  ╚██╔╝      ██╔══██║██║██║   ██║██╔══██║██║   ██║
██████╔╝   ██║       ██║  ██║██║╚██████╔╝██║  ██║╚██████╔╝
╚═════╝    ╚═╝       ╚═╝  ╚═╝╚═╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ 
																		   
[🛠 ] Bot Online`);

const DiscordBot = new Client({
    token: process.env.DISCORD_TOKEN,
    discord: {
        intents: [3243773,
            GatewayIntentBits.Guilds,
            GatewayIntentBits.GuildMembers,
            GatewayIntentBits.GuildModeration,
            GatewayIntentBits.GuildMessages,
            GatewayIntentBits.MessageContent]
    }
})

module.exports = DiscordBot;
