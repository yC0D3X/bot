const { Schema, model } = require("mongoose");

const userSet = new Schema({
    _id: { type: String },
    dmMessages: {
        remind: { type: Boolean, default: true },
        ticket: { type: Boolean, default: true }
    },
    reminds: [
        {
            remind: { type: String },
            remindTime: { type: String },
            remindTimePass: { type: String },
            chatRemindCreated: { type: String },
            ended: { type: Boolean }
        }
    ]
});

  module.exports = model("Usuários", userSet);