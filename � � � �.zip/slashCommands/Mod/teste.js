const { EmbedBuilder, PermissionFlagsBits, ApplicationCommandOptionType } = require("discord.js");
const Discord = require("discord.js");
const ms = require("ms");

module.exports = {
  name: "sorteio",
  description: "crie um sorteio",
  options: [
    {
      name: "premio",
      type: Discord.ApplicationCommandOptionType.String,
      description: "qual sera o premio?",
      required: true,
    },
    {
      name: "regras",
      type: Discord.ApplicationCommandOptionType.String,
      description: "descrição do sorteio",
      required: true,
    },
    {
      name: "tempo",
      type: Discord.ApplicationCommandOptionType.String,
      description: "escolha o tempo do sorteio",
      required: true,
      choices: [ // Você pode acrescentar mais tempos! Caso não saiba adicionar chame no pv
        {
          name: "30 Segundos",
          value: "30s",
        },
        {
          name: "1 Minuto",
          value: "1m",
        },
        {
          name: "5 Minutos",
          value: "5m",
        },
        {
          name: "10 Minutos",
          value: "10m",
        },
        {
          name: "15 Minutos",
          value: "15m",
        },
        {
          name: "30 Minutos",
          value: "30m",
        },
        {
          name: "45 Minutos",
          value: "45m",
        },
        {
          name: "1 Hora",
          value: "1h",
        },
        {
          name: "2 Horas",
          value: "2h",
        },
        {
          name: "5 Horas",
          value: "5h",
        },
        {
          name: "12 Horas",
          value: "12h",
        },
        {
          name: "24 Horas",
          value: "24h",
        },
        {
          name: "1 Dia",
          value: "24h",
        },
        {
          name: "3 dias",
          value: "72h",
        },
        {
          name: "1 Semana",
          value: "168h",
        },
      ],
    },
  ],

  exec: async ({client, interaction, args}) => {
    if (
      !interaction.member.permissions.has(
        Discord.PermissionFlagsBits.ModerateMembers
      )
    ) {
      return interaction.reply({
        content: `**<:hdev_cancelar:1160922757639446589> | ${interaction.user}, Você precisa da permissão de \`MODERATE_MEMBERS\` para usar este comando!**`,
        ephemeral: true,
      });
    } else {
      let premio = interaction.options.getString("premio");
      let tempo = interaction.options.getString("tempo");
      let desc = interaction.options.getString("regras");

      let duracao = ms(tempo);

      const button = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
          .setCustomId("botao")
          .setEmoji("<a:aliendance:876104160154640384>")
          .setStyle(2)
      );

      let click = [];

      const embed = new Discord.EmbedBuilder()
        .setTitle(`<a:876104193138622544:1164986309958451251> **Sorteio**`)
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setDescription(
          `> <:hdev_ponto:1167101509641703474> *Sorteio enviado por* ${interaction.user}\n\n > <:hdev_ponto:1167101509641703474> *Premio:* **${premio}**\n\n > <:hdev_ponto:1167101509641703474> *Regras do sorteio:* **${desc}** \n\n\ > <:hdev_ponto:1167101509641703474> *Duração:* **${tempo}**  \n\n\ *clique no botão a baixo para participar!*`
        )
        .setTimestamp(Date.now() - ms(tempo))
        .setFooter({ text: "Bianchi's Company ©" })
        .setColor(client.config.mainColor);

      let erro = new Discord.EmbedBuilder()
        .setColor(client.config.mainColor)
        .setDescription(`Não foi possível iniciar o soteio!`);

      const msg = await interaction
        .reply({
          embeds: [embed],
          components: [button],
        })
        .catch((e) => {
          interaction.reply({ embeds: [erro] });
        });

      const coletor = msg.createMessageComponentCollector({
        time: ms(tempo),
      });

      coletor.on("end", (i) => {
        interaction.editReply({
          components: [],
        });
      });

      coletor.on("collect", (i) => {
        if (i.customId === "botao") {
          if (click.includes(i.user.id))
            
          
          return i.reply({
              content: `<:hdev_cancelar:1160922757639446589> *Ola ${interaction.user}, Você já está participando do sorteio!*`,
              ephemeral: true,
            });
          click.push(i.user.id);
          interaction.editReply({
            embeds: [embed],
          });
          i.reply({
            content: `<:hdev_aprovar:1167099618027376725> *Ola ${interaction.user}, Você acaba de entrar no sorteio e concorrer ao ${premio}*`,
            ephemeral: true,
          });
        }
      });

      setTimeout(() => {
        let ganhador = click[Math.floor(Math.random() * click.length)];

        if (click.length == 0) {

        let cancelado = new Discord.EmbedBuilder()
        .setTitle('<:hdev_cancelar:1160922757639446589> **Cancelado**')
        .setDescription(`<:hdev_cancelar:1160922757639446589> *O sorteio foi cancelado pois não houve participantes o suficiente*`)
        .setColor(client.config.mainColor)

        
        return interaction.channel.send({ embeds: [cancelado], content: `@everyone`})};

          let embedganhador = new Discord.EmbedBuilder()
          .setTitle('<a:estrela:1130987392698945637> **Parabens**')
          .setDescription(`<a:876104193138622544:1164986309958451251> *Parabens ${interaction.user} \`${interaction.user.tag}\`, voce acaba de ganhar um* **${premio}**`)
          .setColor(client.config.mainColor)
          .setThumbnail('https://gifs.eco.br/wp-content/uploads/2022/09/gifs-de-presentes-9.gif')
          interaction.channel.send({embeds: [embedganhador], content: `${interaction.user}` })
          
    }, duracao);
    }
  },
};
//!    iBielxz#0001

