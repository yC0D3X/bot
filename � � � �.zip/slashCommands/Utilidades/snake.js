const { Snake } = require('discord-gamecord')

module.exports = {
  name: "snake", 
  
  description: "Jogo da cobrinha com botões",
   
  exec: async ({client, interaction, args}) => {
new Snake({
  message: interaction,
  embed: {
    title: 'Jogo da Cobrinha',
    color: '#f26658',
    OverTitle: "Fim de Jogo!",
  },
  snake: { head: '🟢', body: '🟩', tail: '🟢' },
  emojis: {
    board: '⬛', 
    food: '🍎',
    up: '⬆️', 
    right: '➡️',
    down: '⬇️',
    left: '⬅️',
  },
}).startGame()
  }
              }