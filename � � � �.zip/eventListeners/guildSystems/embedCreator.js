

const Discord = require("discord.js");

module.exports = {
    once: false,
    eventName: "interactionCreate",
    exec: async (client, interaction) => {

        const renderModal = {
            setColor: async ()=>{
              const Embed = interaction.message.embeds[0]
        
              const modal = new Discord.ModalBuilder()
                .setCustomId("setColor")
                .setTitle('Setar content');
        
              const contentRow = new Discord.TextInputBuilder()
                .setCustomId('color')
                .setLabel("Cor da Embed:")
                .setRequired(false)
                .setStyle(Discord.TextInputStyle.Short);

              const firstActionRow = new Discord.ActionRowBuilder().addComponents(contentRow);
              modal.addComponents(firstActionRow);
        
              return await interaction.showModal(modal);
            },
            setTitle: async ()=>{
              const Embed = interaction.message.embeds[0]
        
              const modal = new Discord.ModalBuilder()
                .setCustomId("setTitle")
                .setTitle('Setar Titulo');
        
              const contentRow = new Discord.TextInputBuilder()
                .setCustomId('title')
                .setLabel("Titulo da Embed:")
                .setValue(Embed.data.title || "")
                .setRequired(false)
                .setStyle(Discord.TextInputStyle.Short);

              const firstActionRow = new Discord.ActionRowBuilder().addComponents(contentRow);
              modal.addComponents(firstActionRow);
        
              return await interaction.showModal(modal);
            },
            setAuthor: async ()=>{
              const Embed = interaction.message.embeds[0]
        
              const modal = new Discord.ModalBuilder()
                .setCustomId("setAuthor")
                .setTitle('Setar Author');
        
              const nameAuthor = new Discord.TextInputBuilder()
                .setCustomId('nameAuthor')
                .setLabel("Nome do Author da Embed:")
                .setValue(Embed.data.author?.name || "")
                .setRequired(false)
                .setStyle(Discord.TextInputStyle.Short);
        
              const iconAuthor = new Discord.TextInputBuilder()
                .setCustomId('iconAuthor')
                .setLabel("Link do icone do Autor da Embed:")
                .setValue(Embed.data.author?.iconURL || "")
                .setRequired(false)
                .setStyle(Discord.TextInputStyle.Short);
        
              const nameAuthorRow = new Discord.ActionRowBuilder().addComponents(nameAuthor);
              const iconAuthornRow = new Discord.ActionRowBuilder().addComponents(iconAuthor);
              modal.addComponents(nameAuthorRow, iconAuthornRow);
        
              return await interaction.showModal(modal);
            },
            setDescription: async ()=>{
              const Embed = interaction.message.embeds[0]
        
              const modal = new Discord.ModalBuilder()
                .setCustomId("setDescription")
                .setTitle('Setar a Descrição');
        
              const contentRow = new Discord.TextInputBuilder()
                .setCustomId('description')
                .setLabel("Descrição da Embed:")
                .setValue(Embed.data?.description || "")
                .setRequired(false)
                .setMaxLength(2000)
                .setStyle(Discord.TextInputStyle.Paragraph);

              const firstActionRow = new Discord.ActionRowBuilder().addComponents(contentRow);
              modal.addComponents(firstActionRow);
        
              return await interaction.showModal(modal);
            },
            setThumbnail: async ()=>{
              const Embed = interaction.message.embeds[0]
              
              const modal = new Discord.ModalBuilder()
                .setCustomId("setThumbnail")
                .setTitle('Setar a thumbnail');
        
              const contentRow = new Discord.TextInputBuilder()
                .setCustomId('thumbnail')
                .setLabel("Link da thumbnail da Embed:")
                .setValue(Embed.data?.thumbnail?.url || "")
                .setRequired(false)
                .setStyle(Discord.TextInputStyle.Short);

              const firstActionRow = new Discord.ActionRowBuilder().addComponents(contentRow);
              modal.addComponents(firstActionRow);
        
              return await interaction.showModal(modal);
            },
            addField: async ()=>{
              const Embed = interaction.message.embeds[0]
        
              const modal = new Discord.ModalBuilder()
                .setCustomId("addField")
                .setTitle('Adicionar Field');
        
              const contentRow = new Discord.TextInputBuilder()
                .setCustomId('fieldName')
                .setLabel("Titulo do Field:")
                .setMaxLength(255)
                .setRequired(true)
                .setStyle(Discord.TextInputStyle.Short);

              const content2Row = new Discord.TextInputBuilder()
                .setCustomId('fieldValue')
                .setLabel("Descrição do Field:")
                .setMaxLength(1024)
                .setRequired(true)
                .setStyle(Discord.TextInputStyle.Paragraph);

              const firstActionRow = new Discord.ActionRowBuilder().addComponents(contentRow);
              const first2ActionRow = new Discord.ActionRowBuilder().addComponents(content2Row);
              modal.addComponents(firstActionRow, first2ActionRow);
        
              return await interaction.showModal(modal);
            },
            addFieldRemove: async ()=>{
                
                const Embed = interaction.message.embeds[0]
            
                const modal = new Discord.ModalBuilder()
                    .setCustomId("addFieldRemove")
                    .setTitle('Remover field');
            
                const contentRow = new Discord.TextInputBuilder()
                    .setCustomId('field')
                    .setLabel("Numero do Field que deseja remover:")
                    .setRequired(false)
                    .setStyle(Discord.TextInputStyle.Short);

                const infosRow = new Discord.TextInputBuilder()
                    .setCustomId('infosRow')
                    .setLabel("Informações dos Fields:")
                    .setValue(`${Embed.data.fields?.map((field, i)=> `Field: ${field.name} | Número ${++i}`)?.join("\n") || "Sem Fields para remover"}`)
                    .setStyle(Discord.TextInputStyle.Paragraph);
                    
                const firstActionRow = new Discord.ActionRowBuilder().addComponents(contentRow);
                const lastActionRow = new Discord.ActionRowBuilder().addComponents(infosRow);
                modal.addComponents(firstActionRow, lastActionRow);
            
                return await interaction.showModal(modal);
            },
            setImage: async ()=>{
              const Embed = interaction.message.embeds[0]
        
              const modal = new Discord.ModalBuilder()
                .setCustomId("setImage")
                .setTitle('Setar Imagem');
        
              const contentRow = new Discord.TextInputBuilder()
                .setCustomId('image')
                .setLabel("Link da imagem da Embed:")
                .setValue(Embed.data?.image?.url || "")
                .setRequired(false)
                .setStyle(Discord.TextInputStyle.Short);

              const firstActionRow = new Discord.ActionRowBuilder().addComponents(contentRow);
              modal.addComponents(firstActionRow);
        
              return await interaction.showModal(modal);
            },
            setTimestamp: async ()=>{
              let Embed = new Discord.EmbedBuilder(interaction.message.embeds[0])
              if(Embed.data.timestamp) Embed.setTimestamp(null)
              else Embed.setTimestamp()
              interaction.update({ embeds: [Embed]})
            },
            setFooter: async ()=>{
              const Embed = interaction.message.embeds[0]
        
              const modal = new Discord.ModalBuilder()
                .setCustomId("setFooter")
                .setTitle('Setar Footer');
        
              const nameAuthor = new Discord.TextInputBuilder()
                .setCustomId('textFooter')
                .setLabel("Texto do Footer da Embed:")
                .setValue(Embed.data?.footer?.text || "")
                .setRequired(false)
                .setStyle(Discord.TextInputStyle.Short);
        
              const iconAuthor = new Discord.TextInputBuilder()
                .setCustomId('iconFooter')
                .setLabel("Icon do Footer da Embed:")
                .setValue(Embed.data?.footer?.iconURL || "")
                .setRequired(false)
                .setStyle(Discord.TextInputStyle.Short);
        
              const nameAuthorRow = new Discord.ActionRowBuilder().addComponents(nameAuthor);
              const iconAuthornRow = new Discord.ActionRowBuilder().addComponents(iconAuthor);
              modal.addComponents(nameAuthorRow, iconAuthornRow);
        
              return await interaction.showModal(modal);
            }
          }
        if(interaction.isButton()){
            const { customId: Button } = interaction

            renderModal[Button]?.()

            if(Button == "cancelEmbed"){
                interaction.update({ embeds: [], components: [], content: `Criação de embed cancelada...`})
            }
            if(Button.startsWith("sendEmbed")){
                const [, channelId] = Button.split("/")
                const channel = interaction.guild.channels.cache.get(channelId)
                if(channel){
                    await channel.send({ embeds: [interaction.message.embeds[0]]}).catch(e=>{
                        interaction.update({ embeds: [], components: [], content: `Não foi possivel enviar a mensagem no canal ${channel} por: ${e}`}).catch(e=>{})
                    })
                    interaction.update({ embeds: [], components: [], content: `Mensagem enviada com sucesso para o canal ${channel}`}).catch(e=>{})
                } else {
                    interaction.update({ embeds: [], components: [], content: `Perdão mas este canal não existe mais... Use o comando novamente.`})
                }
            }
        }
        if(interaction.isModalSubmit()){
            const { customId: Modal } = interaction

            if(Modal.startsWith("set") || Modal.startsWith("addF")){

                let Embed = new Discord.EmbedBuilder(interaction.message.embeds[0])
                if(Modal == "setColor"){
                  const color = interaction.fields.getTextInputValue('color') || null;
                  
                  try{
                    Embed.setColor(color)
                  } catch {
                    return interaction.reply({ content: `Cor Inválida`, ephemeral: true })
                  }
                }
        
                if(Modal == "setTitle"){
                  const title = interaction.fields.getTextInputValue('title') || null;
                  
                  try{
                    Embed.setTitle(title)
                  } catch {
                    return interaction.reply({ content: `Título Inválido`, ephemeral: true })
                  }
                }
        
                if(Modal == "setAuthor"){
                  const infos = {
                    name: interaction.fields.getTextInputValue('nameAuthor') || null,
                    iconURL: interaction.fields.getTextInputValue('iconAuthor') || null
                  }
                  
                  try{
                    Embed.setAuthor(infos)
                  } catch(e) {
                    return interaction.reply({ content: `Author Inválido`, ephemeral: true })
                  }
                }
        
                if(Modal == "setDescription"){
                  const description = interaction.fields.getTextInputValue('description') || null;
                  
                  try{
                    Embed.setDescription(description)
                  } catch {
                    return interaction.reply({ content: `Descrição Inválida`, ephemeral: true })
                  }
                }
        
                if(Modal == "setThumbnail"){
                  const thumbnail = interaction.fields.getTextInputValue('thumbnail') || null;
                  
                  try{
                    Embed.setThumbnail(thumbnail)
                  } catch {
                    return interaction.reply({ content: `Thumbnail Inválida`, ephemeral: true })
                  }
                }
                
                if(Modal == "addField"){
                  const infos = {
                    name: interaction.fields.getTextInputValue('fieldName') || null,
                    value: interaction.fields.getTextInputValue('fieldValue') || null,
                    inline: true
                  }
                  
                  try{
                    Embed.addFields(infos)
                  } catch {
                    return interaction.reply({ content: `Field Inválido`, ephemeral: true })
                  }
                }
                if(Modal == "addFieldRemove"){
                  const number = interaction.fields.getTextInputValue('field') || null;
                  
                  try{
                    Embed.data.fields = Embed.data.fields.filter(field=>{
                      const sameName = field.name != Embed.data.fields[Number(number) - 1]?.name
                      const sameValue = field.value != Embed.data.fields[Number(number) - 1]?.value
                      return sameName || sameValue
                    })
                  } catch {
                    return interaction.reply({ content: `Field Inválido`, ephemeral: true })
                  }
                }
        
                if(Modal == "setImage"){
                  const image = interaction.fields.getTextInputValue('image') || null;
        
                  try{
                    Embed.setImage(image)
                  } catch {
                    return interaction.reply({ content: `Imagem Inválida`, ephemeral: true })
                  }
                }
        
                if(Modal == "setFooter"){
                  const infos = {
                    text: interaction.fields.getTextInputValue('textFooter') || null,
                    iconURL: interaction.fields.getTextInputValue('iconFooter') || null
                  }
                  
                  try{
                    Embed.setFooter(infos)
                  } catch(e) {
                    return interaction.reply({ content: `Footer Inválido`, ephemeral: true })
                  }
                }
                
                interaction.update({ embeds: [Embed] }).catch(e=>{
                  interaction.reply({ content: "Opa amigo... Ocorreu um erro durante a sua ação. Por favor tente novamente.", ephemeral: true})
                })
              }
        }
    }
}