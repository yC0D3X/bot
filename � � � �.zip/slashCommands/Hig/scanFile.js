const Discord = require("discord.js");
const axios = require('axios');
module.exports = {
  name: "contabilizar",
  description: "Verificar informações do arquivo.",
  options: [
    {
        name: "arquivo",
        description: "arquivo com as infos",
        type: Discord.ApplicationCommandOptionType.Attachment,
        required: false
    }
  ],
  exec: async ({client, interaction}) => {
    // if(![client.config.ownerId].includes(interaction.user.id)) return interaction.reply({ content: "Somente o Adm pode usar este comando", ephemeral: true })
    await interaction.deferReply({ ephemeral: true })
    const attachment = interaction.options.getAttachment("arquivo")

    if(!attachment){
        const msgReply = await interaction.followUp({ content: "> **Envie o arquivo.**", fetchReply: true })
        const collector = interaction.channel.createMessageCollector({ filter: m=> m.author.id == interaction.user.id, idle: 15_000 });

        collector.on('collect', m => {
            const attachment = [...m.attachments.values()][0]
            setTimeout(()=>m.delete().catch(e=>{}), 1500)
            if(attachment){
                collector.stop()
                verify(attachment)
            } else {
                interaction.followUp({ content: "> **Não envie mensagens, envie apenas arquivos `.txt`.**", ephemeral: true })
            }
        });
        collector.on('end', (c, m) => {
            if(m == "idle") interaction.editReply({ content: "> Arquivo não enviado a tempo, use o comando novamente."})
        });
    } else {
        verify(attachment)
    }

    function verify(attachment){
        if(!attachment.contentType.includes("text/plain;")) return interaction.followUp({ content: "> **Perdão, mas eu não consigo ler este formato de arquivo.**", ephemeral: true })

        axios.get(attachment.url)
        .then(async response => {
            const string = response.data;
                    
            const embedContentSplited = string.split(`Bate Ponto`)

            const infos = {}
            embedContentSplited.forEach((content, i)=>{
                const lines = content.split("\n")

                const name = lines[1],
                time = lines[3]
                const relatorio = embedContentSplited[--i]?.split("\n")[5]

                if(!time?.includes("Tempo de serviço:")) return;
                if(!name || !time) return;
                if(relatorio?.split(": ")[1].includes("Não informado ou muito curto.")) return; 
                infos[name] ? infos[name] += transforTime(time) : infos[name] = transforTime(time)
            })

            function transforTime(time){
                time = time.split(": ")[1]
                time = time.split(" ")
                let totalTime = 0

                const multplicate = {
                    d: 1000 * 60 * 60 * 24,
                    h: 1000 * 60 * 60,
                    m: 1000 * 60
                }

                time.forEach((data, index)=>{
                    if(isNaN(data)) return;
                    totalTime += data * multplicate[time[++index][0]]
                })

                return totalTime
            }

            const infosInArray = Object.entries(infos)
            infosInArray.sort((a,b)=> b[1] - a[1])

            const embed = new Discord.EmbedBuilder()
            .setAuthor({ iconURL: client.user.avatarURL(), name: "Tempo somado dos usuários:"})
            .setDescription(`\`\`\`${infosInArray.map(infos=>{
                return `${infos[0].replace("\r", "")} - ${transformSeconds(infos[1])}`
            }).join("\n") || "Informações não encontradas no arquivo."}\`\`\``)
            .setColor("Green")
            .setTimestamp()

            await interaction.editReply({ embeds: [embed], content: null })
        })

    }
  }
}

function transformSeconds(sec){
  const segundosTotal = ~~(sec / 1000)
  const minutos = ~~(segundosTotal / 60)
  const horas = ~~(minutos / 60)
  const segundos = segundosTotal % 60
  return [`${horas% 60}h`,`${minutos% 60}m`, `${segundos}s`].filter(num => !num.startsWith("0")).map(num => num.padStart(3,0)).join(" ")
}
