const { PermissionFlagsBits, ApplicationCommandOptionType, EmbedBuilder } = require("discord.js");

module.exports = {
    name: 'fila',
    description: '.',
    options: [
        {
            name: "de",
            description: ".",
            type: ApplicationCommandOptionType.SubcommandGroup,
            options: [
                {
                    name: "reprodução",
                    description: "Ver a lista de músicas que ainda vão tocar.",
                    type: ApplicationCommandOptionType.Subcommand
                }
            ]
        }
    ],
    exec: async ({client, interaction}) => {
        const serverDB = await client.dbGuild.findOne({ _id: interaction.guild.id })

        if(!serverDB.music.admPermToUse){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, não sou autorizado a poder usar meus comandos de musica neste servidor.`, iconURL: client.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        const player = client.vulkava.players.get(interaction.guild.id);

        if(!player){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, eu não estou tocando música.`, iconURL: client.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        const queueDetails = player.queue

        if(!queueDetails.size){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Um momentinho...`, iconURL: client.user.avatarURL() })
                .setDescription(`> Perdão, não tem nenhuma musica na lista para ser tocada no momento, digite \`/tocando agora\` para ver a música que está tocando.`)
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        const [firtsMusic, ...musicsInQueue] = queueDetails.tracks.slice(0,25).map((track)=>{
            return `[${track.title}](${track.metadata?.uri || track.uri}) | ${transformSeconds(track.duration)}`
        })
        interaction.reply({ embeds: [
            new EmbedBuilder()
            .setAuthor({ name: `Músicas na fila de reprodução:`, iconURL: interaction.guild.iconURL() })
            .addFields(
                {
                    name: "🎶 **Quantidade de músicas:**",
                    value: `${queueDetails.size}`,
                    inline: true
                },
                {
                    name: "⏳ **Duração:**",
                    value: `${transformSeconds(queueDetails.duration)}`,
                    inline: true
                }
            )
            .setDescription(`
            *Próxima música:*
            > ${firtsMusic}
            
            ${queueDetails.size >= 2 ? `*Próximas:*` : ""}
            ${musicsInQueue.join("\n")}
            ${queueDetails.size > 25 ? `***Mais ${queueDetails.size - 25}...***` : ""}`)
            .setColor(client.config.mainColor)
          ]});

    }
}

function transformSeconds(sec){
    const segundosTotal = ~~(sec / 1000)
    const minutos = ~~(segundosTotal / 60)
    const horas = ~~(minutos / 60)
    const segundos = segundosTotal % 60
    return [`${horas% 60}h`,`${minutos% 60}m`, `${segundos}s`].filter(num => !num.startsWith("0")).map(num => num.padStart(3,0)).join(" ")
  }

