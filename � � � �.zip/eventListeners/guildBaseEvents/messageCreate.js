const ms = require("ms")
module.exports = {
    once: false,
    eventName: "messageCreate",
    exec: async (client, message, args) => {
        
        if(message.content.startsWith(client.config.prefix)){
            const [comando, ...args] = message.content.slice(client.config.prefix.length).trim().split(/ +/)
            
            const cmd = client.loader.prefixCommands.find(cmd => cmd.name.toLowerCase() == comando.toLowerCase());

            if(!cmd) return message.reply(`Calma ae, esse comando não existe.`)
            
            cmd.exec({client, message, args})
        }
        
        if (message.author.bot || [client.config.ownerId].includes(message.author.id)) return;

        const reg = /(https?:\/\/)?(www\.)?(discord\.(gg|io|me|li|com)|discordapp\.com\/invite)\/.+[a-z]/g;
        if (reg.test(message.content.toLowerCase().replace(/\s+/g, ''))) return message.reply(`<@!${message.member.id}>, não divulgue links de outros servidores aqui!`).then(msg => {
            const time = ms("6d")
            message.delete().catch(() => { });
            message.member.timeout(time, "Divulgação de servidores").catch((err) => {
                console.log(err)
            });
        })

        if (message.channel.id == '982095581847646217') {
            const msg = message.content.toLowerCase()
            if (msg.startsWith('!id')) return;
            message.delete().catch(() => { })
        }
    }
}