const { EmbedBuilder, ApplicationCommandOptionType, PermissionFlagsBits, parseEmoji, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js")

module.exports = {
    name: "emoji",
    description: "gerencia o modo de emojis",
    options: [
        {
            name: "add",
            description: "Add an emoji to the server.",
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "emoji",
                    description: "Select the emoji you want to add to the server",
                    type: ApplicationCommandOptionType.String,
                    required: true
                },
                {
                    name: "name",
                    description: "Write the name of the emoji",
                    type: ApplicationCommandOptionType.String,
                    required: false,
                }
            ],
        }, {
            name: "info",
            description: "View information about an emoji.",
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "emoji",
                    description: "Select the emoji you want to see more information about",
                    type: ApplicationCommandOptionType.String,
                    required: true
                },
            ],
        }
    ],
    exec: async({client, interaction}) => {

        switch (interaction.options.getSubcommand()) {

            case "add": {

                if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageEmojisAndStickers)) {
                    return interaction.reply({ content: `<:err:1082457199764316320> I need the \`ManageEmojisAndStickers\` permission to run this command`, ephemeral: true, allowedMentions: { repliedUser: true } })
                }
                if (!interaction.channel.permissionsFor(interaction.user).has(PermissionFlagsBits.ManageEmojisAndStickers)) {
                    return interaction.reply({ content: `<:err:1082457199764316320> You need the \`ManageEmojisAndStickers\` permission to run this command`, ephemeral: true, allowedMentions: { repliedUser: true } })
                }
                
                let name = interaction.options.getString("name");
                const string = interaction.options.getString("emoji");
        
                const error_embed = new EmbedBuilder()
                    .setColor("#765cf5")
                    .setDescription("<:err:1082457199764316320> Unable to add emoji, check if you have reached the emoji limit on the server\n> Remember, you can only add custom emojis");
        
                const parsed = parseEmoji(string);
        
                const link = `https://cdn.discordapp.com/emojis/${parsed.id}${parsed.animated ? '.gif' : '.png'}`;

                if (!name) name = parsed.name;

                interaction.guild.emojis
                    .create({ attachment: link, name: `${name}` })
                    .then((em) => {
                        interaction.reply({ content: `${em} **|** ${interaction.user} Emoji successfully added!` })
                    })
                    .catch((error) => {
                        console.log(error)
                        return interaction.reply({
                            embeds: [error_embed],
                            ephemeral: true,
                        });
                    });

                break;
            } // fim do add emoji

            case "info": {

                const emote = interaction.options.getString('emoji');
		        const regex = emote.replace(/^<a?:\w+:(\d+)>$/, '$1');

		        const emoji = interaction.guild.emojis.cache.find((emj) => emj.id === regex);
		        if (!emoji) {
			        const embed1 = new EmbedBuilder()
				        .setDescription('Please enter a valid custum emoji from this server.')
				        .setColor("#765cf5")

			        return interaction.reply({
				        embeds: [embed1],
				        ephemeral: true,
			        });
		        }

		        const row = new ActionRowBuilder().addComponents(
			        new ButtonBuilder()
				        .setLabel('Open in the browser')
				        .setURL(`https://cdn.discordapp.com/emojis/${emoji.id}${emoji.animated ? '.gif' : '.png'}`)
				        .setStyle(ButtonStyle.Link),
		        );

		        const embed2 = new EmbedBuilder()
			        .setTitle(`${emoji} ${emoji.name}`)
			        .setColor("#765cf5")
			        .setThumbnail(emoji.url)
			        .addFields(
				    {
					    name: '<:id_emoji:1068217420503863330> ID:',
					    value: `\`\`\`${emoji.id}\`\`\``,
					    inline: true,
				    },
				    {
					    name: '<:mention:1059964035442937886> Mention:',
					    value: emoji.animated ? `\`\`\`<a:${emoji.name}:${emoji.id}>\`\`\`` : `\`\`\`<:${emoji.name}:${emoji.id}>\`\`\``,
					    inline: true,
				    },
				    {
					    name: '<:dateup:1072358114810155008> Creation Date:',
					    value: `<t:${Math.floor(emoji.createdTimestamp / 1000)}:f>`,
					    inline: true,
				    },
				    {
					    name: '<:wumpostech:1071556074567643186> Type:',
					    value: `${emoji.animated ? 'Animated Image' : 'Static Image'}`,
					    inline: false,
				    },
			    );

		            interaction.reply({
			            embeds: [embed2],
			            components: [row],
		            });

                break;
            }

        }

    }
}