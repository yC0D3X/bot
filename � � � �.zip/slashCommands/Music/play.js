const { PermissionFlagsBits, ApplicationCommandOptionType, EmbedBuilder } = require("discord.js");
const { getPreview } = require('spotify-url-info')(fetch)

module.exports = {
    name: 'play',
    description: 'Tocar musicas',
    options: [
        {
            name: "musica",
            description: "Nome ou link da musica que deseja ouvir.",
            type: ApplicationCommandOptionType.String,
            required: true
        }
    ],
    exec: async ({client, interaction}) => {
        const serverDB = await client.dbGuild.findOne({ _id: interaction.guild.id })

        if(!serverDB.music.admPermToUse){
            return interaction.reply({ embeds: [
                new EmbedBuilder()
                .setAuthor({ name: `Perdão, não sou autorizado a poder usar meus comandos de musica neste servidor.`, iconURL: client.user.avatarURL() })
                .setColor(client.config.mainColor)
              ], ephemeral: true});
        }

        await interaction.deferReply({})
        
        if (!interaction.member.voice.channel){
          return interaction.followUp({ embeds: [
            new EmbedBuilder()
            .setAuthor({ name: `Perdão, você deve estar em uma call para usar esse comando.`, iconURL: client.user.avatarURL() })
            .setColor(client.config.mainColor)
          ], ephemeral: true});
        }
        if(client.vulkava.players.get(interaction.guild.id) && interaction.guild.members.me.voice.channel?.id && interaction.member.voice.channel?.id != interaction.guild.members.me.voice.channel?.id){
          return interaction.followUp({ embeds: [
              new EmbedBuilder()
              .setAuthor({ name: `Perdão, ja estou em uso em outra call.`, iconURL: client.user.avatarURL() })
              .setColor(client.config.mainColor)
            ], ephemeral: true});
        }

        const track = interaction.options.getString('musica');

        const res = await client.vulkava.search(track);

        if (res.loadType === "LOAD_FAILED") {
           interaction.followUp({ content: `> Perdão, ocorreu um erro ao tentar tocar a música. Tente novamente mais tarde.`});
           return console.log(`[ERRO AO TOCAR MUSICA] ${res.exception.message}`)
        } else if (res.loadType === "NO_MATCHES") {
          return interaction.followUp({ content: `> Perdão, não consegui encontrar essa música, tente digitar algo diferente.`});
        }

        const player = client.vulkava.createPlayer({
          guildId: interaction.guild.id,
          voiceChannelId: interaction.member.voice.channelId,
          textChannelId: interaction.channel.id,
          selfDeaf: true
        });

        player.connect(); 

        if (res.loadType === 'PLAYLIST_LOADED') {

          for (const track of res.tracks) {
            track.setRequester(interaction.user);
            player.queue.add(track);
          }
          
          if(res.tracks[0].source == "spotify"){
            const data = await getPreview(track)
            res.playlistInfo.thumbnail = data.image
          } else {
            res.playlistInfo.thumbnail = res.tracks[0].thumbnail
          }

          interaction.followUp({ embeds:  [
            new EmbedBuilder()
            .setTitle(res.playlistInfo.name)
            .setURL(track)
            .setThumbnail(res.playlistInfo.thumbnail)
            .setColor(client.config.mainColor)
            .setAuthor({ name: "Playlist Carregada com sucesso!"})
            .addFields([
              {
                name: `> **Músicas carregadas:**`,
                value: `${res.tracks.length}`,
                inline: true
              },
              {
                name: `> **Tempo de duração da playlist:**`,
                value: `${transformSeconds(res.playlistInfo.duration)}`,
                inline: true
              }
            ])
          ]})
        } else {
          const track = res.tracks[0];
          track.setRequester(interaction.user);

          player.queue.add(track);

          if(track.source == "spotify"){
            const data = await getPreview(track.uri)
            track.thumbnail = data.image
          }

          interaction.followUp({ embeds: [
            new EmbedBuilder()
            .setTitle(`${track.title}`)
            .setURL(track.uri)
            .setAuthor({ name: `Música adicionada a fila com sucesso!` })
            .setThumbnail(track.thumbnail)
            .setColor(client.config.mainColor)
          ]})
        
        }
        
        if (!player.playing) player.play();
    }
}   
  
function transformSeconds(sec){
  const segundosTotal = ~~(sec / 1000)
  const minutos = ~~(segundosTotal / 60)
  const horas = ~~(minutos / 60)
  const segundos = segundosTotal % 60
  return [`${horas% 60}h`,`${minutos% 60}m`, `${segundos}s`].filter(num => !num.startsWith("0")).map(num => num.padStart(3,0)).join(" ")
}