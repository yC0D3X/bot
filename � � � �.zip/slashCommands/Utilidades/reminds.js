const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

const msgRemindsActives = new Map()

module.exports = {
    msgRemindsActives,
    generateMessageReminds,
    name: 'lembretes',
    description: 'Criar e editar reminds',
    exec: async ({ client, interaction }) => {
        
        if(msgRemindsActives.get(interaction.user.id)){
            return interaction.reply({ content: `Perdão, você ja tem um comando de lembretes ativo, espere uns minutinhos para ele se fechar sozinho ou feche-o para poder usar outro.`, ephemeral: true})
        }

        const message = await generateMessageReminds(client, interaction)
            
        interaction.reply({ embeds: [message.embed], components: [message.row], fetchReply: true, ephemeral: true }).then(msg=>{
            const collector = msg.createMessageComponentCollector({ idle: 1000 * 60 * 1 });
            msgRemindsActives.set(interaction.user.id, msg.id)
            
            collector.on('end', async i => {
                msgRemindsActives.delete(interaction.user.id)
            })
        })

    }
}

async function generateMessageReminds(client, interaction){
    const userDb = await client.dbUser.findById(interaction.user.id) || await client.dbUser.create({ _id: interaction.user.id })

        const row = new ActionRowBuilder()
			.addComponents(
                new ButtonBuilder()
			.setCustomId('createRemind')
			.setLabel('Criar')
			.setStyle(ButtonStyle.Success),
                new ButtonBuilder()
			.setCustomId('editRemind')
			.setLabel('Editar')
            .setDisabled(!userDb.reminds.filter(remind=> !remind.ended ).length)
			.setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
			.setCustomId('deleteRemind')
			.setLabel('Excluir')
            .setDisabled(!userDb.reminds.filter(remind=> !remind.ended ).length)
			.setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
			.setCustomId('clearReminds')
			.setLabel('Limpar lembretes terminados')
            .setDisabled(!userDb.reminds.filter(remind=> remind.ended ).length)
			.setStyle(ButtonStyle.Danger),
            )

        const embed = new EmbedBuilder()
            .setAuthor({ name: `Lembretes de ${interaction.user.username}.`, iconURL: interaction.user.avatarURL() })
            .setDescription(userDb.reminds.length ? "*__Lembrete__* | `Tempo` (Ativo <:hdev_aprovar:1167099618027376725> ou Terminado <:hdev_cancelar:1160922757639446589>)" : "Sem lembretes")
            .addFields(userDb.reminds.map((value, i)=>{ return {
                name: `**Lembrete ${++i}:**`,
                value: `> *__${value.remind}__* | <t:${~~(value.remindTime / 1000)}:R> (${value.ended ? "<:hdev_cancelar:1160922757639446589>" : "<:hdev_aprovar:1167099618027376725>"})`
            } }))
            .setColor(client.config.mainColor);

            return { embed, row }
}