const Discord = require("discord.js");
const config = require("../../src/util/config")
const { guildActivadeSystem } = require("../../eventListeners/guildSystems/gifzada");

module.exports = {
    name: 'ativar',
    description: '.',
    options: [
        {
            name: "sistemas",
            description: "Ativar sistemas nos servidores",
            type: Discord.ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "servidor",
                    description: "Servidor para configurar os sistemas",
                    type: Discord.ApplicationCommandOptionType.String,
                    autocomplete: true,
                    required: true
                }
            ]
        }
    ],
    autoCompleteRun: async (interaction) => {
        if(![config.ownerId].includes(interaction.user.id)) return interaction.respond([])
        const servidor = interaction.options.getFocused()
        let serversFetch = await interaction.client.guilds.fetch()
        serversFetch = Array.from(serversFetch).flat()

        let serversFiltered = serversFetch.filter(guild=> guild.name?.includes(servidor))
        if(!serversFiltered.length && !isNaN(servidor)) serversFiltered = serversFetch.filter(guild=> guild.id?.includes(servidor))

        interaction.respond(serversFiltered.slice(0,10).map(guild=>{
            return {
                name: guild.name,
                value: guild.id
            }
        }))
    }, 
    exec: async ({client, interaction}) => {
        if(![client.config.ownerId].includes(interaction.user.id)) return interaction.reply({ content: "Somente o Adm pode usar este comando", ephemeral: true })
        const server = interaction.options.getString("servidor")
        const guildCache = client.guilds.cache.get(server)
        const guildDb = async ()=> await client.dbGuild.findOne({ _id: server }) || await client.dbGuild.create({ _id: server })

        const generateMessage = async() =>{
            const databaseOfGuild = await guildDb()

            const embedConfigRegistry = new Discord.EmbedBuilder()
            .setAuthor({ name: `Configurar sistemas de ${guildCache.name}`, iconURL: guildCache.iconURL()})
            .addFields(
                {
                    name: `> 🎵  **Sistema de musica:**`,
                    value: databaseOfGuild.music.admPermToUse ? "`✅ Ativo`" : "`❌ Desativado`",
                    inline: true
                },
                {
                    name: `> 🖼  **Sistema de gifs:**`,
                    value: databaseOfGuild.gifzadaSystem.admPermToUse ? "`✅ Ativo`" : "`❌ Desativado`",
                    inline: true
                }
            )
            .setColor(client.config.mainColor);
            
            const buttonsConfigRegistry = new Discord.ActionRowBuilder()
            .addComponents(
                    new Discord.ButtonBuilder()
                    .setCustomId(`music`)
                    .setEmoji(databaseOfGuild.music.admPermToUse ? "<:OnBlue:1152616795350499458>" : "<:Off:1149308391324401674>")
                    .setLabel(databaseOfGuild.music.admPermToUse ? "🎵 Desativar sistema de música" : "🎵 Ativar sistema de música")
                    .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                    .setCustomId(`gifzadaSystem`)
                    .setEmoji(databaseOfGuild.gifzadaSystem.admPermToUse ? "<:OnBlue:1152616795350499458>" : "<:Off:1149308391324401674>")
                    .setLabel(databaseOfGuild.gifzadaSystem.admPermToUse ? "🖼 Desativar sistema de Gifs" : "🖼 Ativar sistema de Gifs")
                    .setStyle(Discord.ButtonStyle.Secondary),
            );

            return { embeds: [embedConfigRegistry], components: [buttonsConfigRegistry], fetchReply: true, ephemeral: true }
        }
            
        interaction.reply(await generateMessage()).then(msg=>{
            
            const collector = msg.createMessageComponentCollector({ idle: 1000 * 60 * 5 });

            collector.on('collect', async i => {
                    const { customId: Button } = i
                        const databaseOfGuild = await guildDb()
                        const obj = {}
                        if(databaseOfGuild[Button].admPermToUse){
                            obj[`${Button}.admPermToUse`] = false
                            if(Button == "gifzadaSystem"){
                                obj[`${Button}.active`] = false
                                databaseOfGuild.gifzadaSystem.active && (clearInterval(guildActivadeSystem[databaseOfGuild._id]))
                            }

                            await client.dbGuild.updateOne({ _id: server },{
                                $set: obj
                            })
                            i.update(await generateMessage())
                        } else {
                            obj[`${Button}.admPermToUse`] = true
                            await client.dbGuild.updateOne({ _id: server },{
                                $set: obj
                            })
                            i.update(await generateMessage())
                        }
            });

        })
    }
}


