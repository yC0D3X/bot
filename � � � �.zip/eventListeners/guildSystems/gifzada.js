const { EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder } = require("discord.js")
const guildActivadeSystem = {}
module.exports = {
    initCountGifzada,
    guildActivadeSystem,
    once: false,
    eventName: "ready",
    exec: async (client) => {
        const selfBot = client.selfBot
        selfBot.start()
        
        client.dbGuild.find().then(guilds=>{
            guilds.forEach(guild=>{
                if(guild.gifzadaSystem.active) {
                    initCountGifzada(guild, selfBot, client)
                }
            })
        }, err=> console.log(err))

    }
}

function initCountGifzada(guildData, selfBot, client){
    const intervalGuild = setInterval(async()=>{
        const guild = await client.dbGuild.findOne({ _id: guildData._id })

        if(selfBot.fetchInProgress) return;
        
        const guildCache = client.guilds.cache.get(guild._id)
        //Gifs
        if(guild.gifzadaSystem.partials.animate.active){
            const usersGifsAnimate = selfBot.usersGets.filter(user=> user.avatarURL.includes(".gif"))
            const user = usersGifsAnimate[~~(Math.random() * usersGifsAnimate.length - 1)]
            
            guildCache?.channels.cache.get(guild.gifzadaSystem.partials.animate.channel)
            .send(generateMessage(user, user.avatarURL))
        }
        //Icon
        if(guild.gifzadaSystem.partials.static.active){
            const usersStaticImages = selfBot.usersGets.filter(user=> !user.avatarURL.includes(".gif"))
            const user = usersStaticImages[~~(Math.random() * usersStaticImages.length - 1)]
            
            guildCache?.channels.cache.get(guild.gifzadaSystem.partials.static.channel)
            .send(generateMessage(user, user.avatarURL))
        }
        //Banners
        if(guild.gifzadaSystem.partials.banner.active){
            const usersBanners = selfBot.usersGets.filter(user=> user.bannerURL)
            if(!usersBanners.length) return;
            const user = usersBanners[~~(Math.random() * usersBanners.length - 1)]
            
            guildCache?.channels.cache.get(guild.gifzadaSystem.partials.banner.channel)
            .send(generateMessage(user, user.bannerURL))
        }
        
        function generateMessage(user, image){
            const embed = new EmbedBuilder()
            .setImage(image)
            .setFooter({ text: `(${user.userId})`, iconURL: user.avatarURL })
            .setColor("#313338")

            const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel('Baixar imagem')
                .setEmoji("<:hdev_download:1181491713345343508>")
                .setStyle(ButtonStyle.Link)
                .setURL(image)
            )
            return { embeds: [embed], components: [button]}
        }
    },  guildData.gifzadaSystem.cooldown)
    guildActivadeSystem[guildData._id] = intervalGuild
}
