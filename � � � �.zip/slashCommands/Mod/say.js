const {
    ApplicationCommandOptionType,
    PermissionFlagsBits,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ActionRowBuilder,
    EmbedBuilder,
    ButtonBuilder,
    ButtonStyle,
    ChannelType
  } = require('discord.js');
  
  module.exports = {
    name: 'say',
    description: 'Faça eu falar algo',
    default_member_permissions: [PermissionFlagsBits.Administrator],
    options: [
      {
        name: 'tipo',
        description: 'Selecione o tipo que eu devo falar',
        required: true,
        type: ApplicationCommandOptionType.String,
        choices: [
          {
            name: 'Texto',
            value: 'text'
          },
          {
            name: 'Embed',
            value: 'embed'
          }
        ]
      },
      {
        name: 'canal',
        description: 'O canal que a mensagem será enviada',
        required: true,
        channel_types: [ChannelType.GuildText,
          ChannelType.PublicThread,
          ChannelType.PrivateThread],
        type: ApplicationCommandOptionType.Channel
      }
    ],
    async exec({ client, interaction }){
      const messageType = interaction.options.getString('tipo');
      const channel = interaction.options.getChannel('canal');
  
      if (messageType === 'embed') {
        const buttons = new ActionRowBuilder()
        .addComponents(
        new ButtonBuilder()
        .setCustomId(`setColor`)
        .setLabel('Setar Cor')
		.setEmoji("<:hdev_paletadecores:1160919735546945596>")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
        .setCustomId(`setTitle`)
        .setLabel('Setar Título')
		.setEmoji("<:hdev_cabecalho:1160919611345223801>")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
        .setCustomId(`setAuthor`)
        .setLabel('Setar Autor')
		.setEmoji("<:hdev_user:1151584770107645995>")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
        .setCustomId(`setDescription`)
        .setLabel('Setar Descrição')
		.setEmoji("<:hdev_editar:1160919781717848206>")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
        .setCustomId(`setThumbnail`)
        .setLabel('Setar Thumbnail')
		.setEmoji("<:hdev_imagem:1160919891717652480>")
        .setStyle(ButtonStyle.Secondary),
        );
        const buttons2 = new ActionRowBuilder()
        .addComponents(
        new ButtonBuilder()
        .setCustomId(`addField`)
        .setLabel('Adicionar Field')
		.setEmoji("<:hdev_mais:1160919957836677222>")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
        .setCustomId(`addFieldRemove`)
        .setLabel('Remover Field')
		.setEmoji("<:hdev_menos:1160920010114482276>")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
        .setCustomId(`setImage`)
        .setLabel('Setar Imagem')
		.setEmoji("<:hdev_imagem:1160919891717652480>")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
        .setCustomId(`setFooter`)
        .setLabel('Setar Footer')
		.setEmoji("<:hdev_rodape:1160919685181735044>")
        .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
        .setCustomId(`setTimestamp`)
        .setLabel('Setar Timestamp')
		.setEmoji("<:hdev_cronometro:1160919847073488947>")
        .setStyle(ButtonStyle.Secondary),
        );
        const buttons3 = new ActionRowBuilder()
        .addComponents(
        new ButtonBuilder()
        .setCustomId(`sendEmbed/${channel.id}`)
        .setLabel('Enviar Embed')
		.setEmoji("<:hdev_enviar:1160928139082469466>")
        .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
        .setCustomId(`cancelEmbed`)
        .setLabel('Cancelar')
		.setEmoji("<:hdev_cancelar:1160922757639446589>")
        .setStyle(ButtonStyle.Success),
        );

        const embed = new EmbedBuilder()
          .setDescription("Crie sua embed")

        interaction.reply({ 
          embeds: [embed],
          components: [buttons, buttons2, buttons3],
          ephemeral: true,
          fetchReply: true
         })
      } else if (messageType === 'text') {
        const myModal = new ModalBuilder()
          .setCustomId(`sayModalText/${channel.id}`)
          .setTitle('Texto');
  
        const messageInput = new TextInputBuilder()
          .setCustomId('Mensagem')
          .setLabel('O que irei falar')
          .setStyle(TextInputStyle.Paragraph);
  
        const row1 = new ActionRowBuilder().addComponents(messageInput);
  
        myModal.addComponents(row1);
        await interaction.showModal(myModal);
       
      }
    }
  };
  