const { EmbedBuilder } = require("discord.js")

module.exports = {
    once: false,
    eventName: "messageUpdate",
    exec: async (client, oldMessage, newMessage) => {
        if(oldMessage.author.bot) return;
        const serverDB = await client.dbGuild.findOne({ _id: oldMessage.guild.id })
        if(!serverDB || !serverDB.messagesLogs.active) return;

        const channelLogs = client.channels.cache.get(serverDB.messagesLogs.channel)

        channelLogs?.send({
         embeds: [
             new EmbedBuilder()
             .setAuthor({ name: `${oldMessage.author.username}(${oldMessage.author.id})`, iconURL: oldMessage.author.avatarURL() })
             .setTitle(`📑 Mensagem de texto editada:`)
             .setColor(client.config.mainColor)
             .addFields(
                {
                    name: `> **Conteúdo antigo:**`,
                    value: `\`\`\`${oldMessage.content}\`\`\``
                },
                {
                    name: `> **Conteúdo novo:**`,
                    value: `\`\`\`${newMessage.content}\`\`\``
                },
             )
             .setTimestamp()
         ]
        })
    }
}