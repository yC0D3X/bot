const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ApplicationCommandOptionType, PermissionFlagsBits } = require("discord.js");

module.exports = {
    name: 'senha',
    description: 'Define a mensagem de suporte.',
    default_member_permissions: [PermissionFlagsBits.Administrator],
    exec: async ({ client, interaction }) => {
        if(![client.config.ownerId].includes(interaction.user.id)) return interaction.reply({ content: "Somente o Adm pode usar este comando", ephemeral: true })
        
        const password = "abcdefghijkllmopqrstuvwxyz1234567890@#%&*>?<".split("").sort(() => Math.random() - 0.5).slice(0,10).join("")

        client.webServerPassword = password

        interaction.reply({
            content: `**Nova senha de acesso foi gerada com sucesso.**\nCopie abaixo:\`\`\`${password}\`\`\``,
            ephemeral: true
        })
    }
}